python2.7 netflix_prepare.py
python2.7 movieLens100K_prepare.py

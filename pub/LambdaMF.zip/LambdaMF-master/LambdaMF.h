//int USER_N = 480190
int USER_N = 100;
int ITEM_N = 100;
//int ITEM_N = 100;
int D = 100;

g++ LambdaMF.cpp -O3 -o LambdaMF

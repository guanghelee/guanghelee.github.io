#!/bin/bash

cd class
echo "complie gbm and hgbm (classification)"
g++ -std=c++11 gbm-train.cpp -o gbm-train
g++ -std=c++11 hgbm-train.cpp -o hgbm-train
cd ../regr
echo "complie gbm and hgbm (regression)"
g++ -std=c++11 gbm-train.cpp -o gbm-train
g++ -std=c++11 hgbm-train.cpp -o hgbm-train
cd ..

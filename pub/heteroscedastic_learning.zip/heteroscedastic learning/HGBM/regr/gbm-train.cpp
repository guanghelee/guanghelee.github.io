#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <cmath>
#include "gbm.cpp"

using namespace std;


int main(int argc, char* argv[]) {
	if (argc != 10) {
		cout << "usage: ./gbm-train {dataset.xy} {# of trees} {gamma} {lambda} {test.xy} {max_height} {error ratio} {error ratio2} {learning rate}" << endl;
		return 0;
	}

    int error_ratio = stoi(argv[7]);
    int error_ratio2 = stoi(argv[8]);

	ifstream f(argv[1]);
	vector<vector<double> > X;
	vector<double> Y;
	read_data(f, X, Y, error_ratio);
	BTForest btforest(stoi(argv[2]), stod(argv[3]), stod(argv[4]), stoi(argv[6]), "MSE", stod(argv[9]));
	ifstream ff(argv[5]);
	vector<vector<double> > X_test;
	vector<double> Y_test;
	read_data(ff, X_test, Y_test, error_ratio2);
	btforest.fit(X, Y, X_test, Y_test);
	int acc = 0; 
	double acc_mse = 0;
	for(int i = 0; i < X.size(); ++i) {
		double p = btforest.predict(X[i]);
		cout << "traindata " << Y[i] << ' ' << p << endl;
		if(Y[i] * p > 1e-9) {
			acc += 1;
		}
		acc_mse += pow(Y[i] - p, 2);
	}
	cout << "final_acc(train) " << 1. * acc / X.size() << endl;
	cout << "final_mse(train) " << 1. * acc_mse / X.size() << endl;
	f.close();

	// testing set
	/*
	f.open(argv[5]);
	vector<vector<double> > X_test;
	vector<int> Y_test;
	read_data(f, X_test, Y_test);
	*/
	acc = 0;
	acc_mse = 0;
	for(int i = 0; i < X_test.size(); ++i) {
		double p = btforest.predict(X_test[i]);
		cout << "testdata " << Y_test[i] << ' ' << p << endl;
		if(Y_test[i] * p > 1e-9) {
			acc += 1;
		}
		acc_mse += pow(Y_test[i] - p, 2);
	}
	cout << "final_acc(test) " << 1. * acc / X_test.size() << endl;
	cout << "final_mse(test) " << 1. * acc_mse / X_test.size() << endl;
	
	return 0;
}


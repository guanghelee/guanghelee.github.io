#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include "hgbm.cpp"

using namespace std;


int main(int argc, char* argv[]) {
	if (argc != 15) {
		cout << "usage: ./hgbm-train {dataset.xy} {# of trees} {gamma} {gamma2} {lambda1} {lambda2} {alpha} {test.xy} {max_height} {max_height2} {error ratio} {error ratio2} {learning_rate1} {learning_rate2}" << endl;
		return 0;
	}

    int error_ratio = stoi(argv[11]);
    int error_ratio2 = stoi(argv[12]);

	ifstream f(argv[1]);
	vector<vector<double> > X;
	vector<double> Y;
	read_data(f, X, Y, error_ratio);
	BTForest btforest(stoi(argv[2]), stod(argv[3]), stod(argv[4]), stod(argv[5]), stod(argv[6]), stod(argv[7]), stoi(argv[9]), stoi(argv[10]), "MSE", "SIGMOID", stod(argv[13]), stod(argv[14]));
	// TODO just test
	ifstream ff(argv[8]);
	vector<vector<double> > X_test;
	vector<double> Y_test;
	read_data(ff, X_test, Y_test, error_ratio2);
	btforest.fit(X, Y, X_test, Y_test, error_ratio);
	int acc = 0; 
    double acc_mse = 0;
    int error_number = static_cast<int>(1. * error_ratio * X.size() / 100);
	ofstream f_tmp("tmp");
	for(int i = 0; i < X.size(); ++i) {
		double p = btforest.predict(X[i]);
		cout << "traindata " << Y[i] << ' ' << p << endl;
		if(Y[i] * p > 1e-9) {
			acc += 1;
		}
		f_tmp << btforest.predict2(X[i]) << endl;
        acc_mse += pow(Y[i] - p, 2);
	}
	f_tmp.close();

    // calculate error detection
    int tp = 0, tn = 0, fp = 0, fn = 0;
    vector<pair<double, int> > error_det;
    for(int i = 0; i < X.size(); ++i) {
        error_det.push_back(std::make_pair(btforest.get_D_hat(i), i));
    }
    std::sort(error_det.rbegin(), error_det.rend());
    for(int i = 0; i < X.size(); ++i) {
        if (i < error_number) {
            cout << "bigerror " << error_det[i].second << endl;
            if (error_det[i].second < error_number) {
                tp += 1;
            } else {
                fp += 1;
            }
        } else {
            if (error_det[i].second < error_number) {
                fn += 1;
            } else {
                tn += 1;
            }
        }
    }

	cout << "final_acc(train) " << 1. * acc / X.size() << endl;
	cout << "final_mse(train) " << 1. * acc_mse / X.size() << endl;
    cout << "precision " << 1. * tp / (tp + fp) << endl;
    cout << "recall " << 1. * tp / (tp + fn) << endl;
    cout << "tp fn tn fp " << tp << ' ' << fn << ' ' << tn << ' ' << fp << endl;
	f.close();

	acc = 0;
    acc_mse = 0;

	for(int i = 0; i < X_test.size(); ++i) {
		double p = btforest.predict(X_test[i]);
		cout << "testdata " << Y_test[i] << ' ' << p << endl;
		if(Y_test[i] * p > 1e-9) {
			acc += 1;
		}
        acc_mse += pow(Y_test[i] - p, 2);
	}
	cout << "final_acc(test) " << 1. * acc / X_test.size() << endl;
	cout << "final_mse(test) " << 1. * acc_mse / X_test.size() << endl;
	f.close();

	return 0;
}


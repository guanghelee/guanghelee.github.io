#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <utility>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cmath>


void read_data(std::ifstream& f, std::vector<std::vector<double> >& X, std::vector<double>& Y, int error_ratio) {
	std::string s;
	while(getline(f, s)) {
		std::stringstream ss(s);
		double y;
		double xi;	
		std::vector<double> x;
		ss >> y;
		Y.push_back(y);
		while(ss >> xi) {
			x.push_back(xi);
		}
		X.push_back(x);
	}
	int sz = static_cast<int>(1. * Y.size() * error_ratio / 100);
	for(int i = 0; i < sz; ++i) {
		Y[i] *= -1;
	}
	return;
}

double fast_sigmoid(double x) {
	//return x / (1 + fabs(x));
	return 1. / (1 + exp(-x));
}

class Node {
public:
	Node() = delete;
	Node(int l, int r):_l(l), _r(r) {}

	int get_left() const { return _l; }
	int get_right() const { return _r; }
	int get_left_idx() const { return _chl; }
	int get_right_idx() const { return _chr; }
	int get_dim() const { return _dim; }
	double get_cut() const { return _cut; }
	double get_wstar() const { return _wstar; }
	double get_mstar() const { return _mstar; }
	bool get_leaf() const { return _leaf; }
	void set_left_idx(int idx) { _chl = idx; }
	void set_right_idx(int idx) { _chr = idx; }
	void set_dim(int dim) { _dim = dim; }
	void set_cut(double cut) { _cut = cut; }
	void set_wstar(double wstar) { _wstar = wstar; }	
	void set_mstar(double mstar) { _mstar = mstar; }
	void set_leaf(bool leaf) { _leaf = leaf; }
private:
	int _l, _r, _chl, _chr;
	int _dim;
	double _cut, _wstar, _mstar;
	bool _leaf = false;
};

class BT {
public:
	BT() = delete;
	BT(double gamma, double lambda, double lambda2, double alpha, int max_height, std::string loss, std::string deviation, double shrinkage, double shrinkage2):_gamma(gamma), _lambda(lambda), _lambda2(lambda2), _alpha(alpha), _max_height(max_height), _loss_function(loss), _deviation_function(deviation), _shrinkage(shrinkage), _shrinkage2(shrinkage2) {}
	
	void fit(std::vector<std::vector<double> >& X, std::vector<double>& Y, std::vector<double>& Y_hat, std::vector<double>& D_hat);
	double predict(std::vector<double>& Xi, int idx) const;
	double predict2(std::vector<double>& Xi, int idx) const;

	void initial_from_loss_function(std::vector<std::vector<double> >& X, std::vector<double>& Y, std::vector<double>&Y_hat, std::vector<double>& D_hat);
	double obj_function() const;
private:
	double _gamma, _lambda, _lambda2, _alpha, eps = 1e-6;
	double _obj_penalty = 0;
	int _max_height;
	double _shrinkage, _shrinkage2;
	std::string _loss_function, _deviation_function;
	std::vector<Node> T;
	std::vector<int> idx;
	std::vector<double> gi, hi, gi2, hi2;

	void grow(int idx, std::vector<std::vector<double> >& X, std::vector<double>& Y, int height);
};

void BT::initial_from_loss_function(std::vector<std::vector<double> >& X, std::vector<double>& Y, std::vector<double>& Y_hat, std::vector<double>& D_hat) {
	// TODO fix here to fit your lose function
	this->gi.clear();
	this->hi.clear();
	this->gi2.clear();
	this->hi2.clear();
	this->idx.clear();
	if (this->_loss_function == "MSE") {
		if (this->_deviation_function == "L2") {
			for(int i = 0; i < X.size(); ++i) {
				this->gi.push_back(2 * (Y_hat[i] - Y[i])
								   / (pow(D_hat[i], 2) + this->eps));
				this->gi2.push_back(pow(Y[i] - Y_hat[i], 2) * (-2) * D_hat[i]
									/ pow(pow(D_hat[i], 2) + this->eps, 2));
				this->hi.push_back(2 / (pow(D_hat[i], 2) + this->eps));
				this->hi2.push_back(pow(Y[i] - Y_hat[i], 2) * (-2)
									* (pow(D_hat[i], 2) + this->eps - 4 * pow(D_hat[i], 2))
									/ pow(pow(D_hat[i], 2) + this->eps, 3));

				this->idx.push_back(i);
			}
		} else if (this->_deviation_function == "SIGMOID") {
			for(int i = 0; i < X.size(); ++i) {
				double fs = fast_sigmoid(D_hat[i]);
				this->gi.push_back(2 * (Y_hat[i] - Y[i])
								   / (1 + this->_alpha * fs));
				this->gi2.push_back(pow(Y[i] - Y_hat[i], 2)
									* (-this->_alpha * fs + this->_alpha * pow(fs, 2))
									/ pow(1 + this->_alpha * fs, 2)
									+ 0);
				this->hi.push_back(2 / (1 + this->_alpha * fs));
				this->hi2.push_back(pow(Y_hat[i] - Y[i], 2)
									* this->_alpha * fs * (1 - fs)
									* (2 * fs + this->_alpha * fs - 1)
									/ pow(1 + this->_alpha * fs, 3)
									+ 0);
				this->idx.push_back(i);
			}
		}
	} else if(this->_loss_function == "LOGREG") {
		if (this->_deviation_function == "L2") {
			for(int i = 0; i < X.size(); ++i) {
				this->gi.push_back(-Y[i] * exp(-Y[i] * Y_hat[i]) 
								   / (1 + exp(-Y[i] * Y_hat[i]))
								   / (pow(D_hat[i], 2) + this->eps));
				this->gi2.push_back(log(1 + exp(-Y[i] * Y_hat[i]))
									* (-2) * (D_hat[i])
									/ pow(pow(D_hat[i], 2) + this->eps, 2)
									//+ 2 * this->_alpha * D_hat[i]);
									+ 0);
				this->hi.push_back(pow(Y[i], 2) * exp(-Y[i] * Y_hat[i])
								   / pow(1 + exp(-Y[i] * Y_hat[i]), 2)
								   / (pow(D_hat[i], 2) + this->eps));
				this->hi2.push_back(log(1 + exp(-Y[i] * Y_hat[i]))
									* 2 * (3 * pow(D_hat[i], 2) - this->eps)
									/ pow(pow(D_hat[i], 2) + this->eps, 3)
									//+ 2 * this->_alpha);
									+ 0);

				this->idx.push_back(i);
			}
		} else if (this->_deviation_function == "SIGMOID") {
			for(int i = 0; i < X.size(); ++i) {
				double fs = fast_sigmoid(D_hat[i]);
				this->gi.push_back(-Y[i] * exp(-Y[i] * Y_hat[i]) 
								   / (1 + exp(-Y[i] * Y_hat[i]))
								   / (1 + this->_alpha * fs));
				this->gi2.push_back(log(1 + exp(-Y[i] * Y_hat[i]))
									* (-this->_alpha * fs + this->_alpha * pow(fs, 2))
									/ pow(1 + this->_alpha * fs, 2)
									//+ 2 * this->_alpha * D_hat[i]);
									+ 0);
				this->hi.push_back(pow(Y[i], 2) * exp(-Y[i] * Y_hat[i])
								   / pow(1 + exp(-Y[i] * Y_hat[i]), 2)
								   / (1 + this->_alpha * fs));
				this->hi2.push_back(log(1 + exp(-Y[i] * Y_hat[i]))
									* this->_alpha * fs * (1 - fs)
									* (2 * fs + this->_alpha * fs - 1)
									/ pow(1 + this->_alpha * fs, 3)
									//+ 2 * this->_alpha);
									+ 0);
				this->idx.push_back(i);
			}
		}
	} else {
		std::cout << "[BT.initial_from_loss_function] Something wrong..." << std::endl;
		return;
	}
}

void BT::fit(std::vector<std::vector<double> >& X, std::vector<double>& Y, std::vector<double>& Y_hat, std::vector<double>& D_hat) {
	this->initial_from_loss_function(X, Y, Y_hat, D_hat);
	
	// construct the root node
	this->T.push_back(Node(0, X.size()));
	this->grow(0, X, Y, 0);
	std::cout << "T.size() " << this->T.size() << std::endl;
}

void BT::grow(int idx, std::vector<std::vector<double> >& X, std::vector<double>& Y, int height) {
	if(idx >= T.size()) {
		std::cout << "[BT.grow] index out of T.size()" << std::endl;
		return;
	}
	int l = this->T[idx].get_left();
	int r = this->T[idx].get_right();
	int ma_dim, ma_cut_idx;
	double ma_cut, ma_gain = -1;
	double gi_total = 0, hi_total = 0, gi2_total = 0, hi2_total = 0;
	for(int i = l; i < r; ++i) {
		gi_total += this->gi[i];
		hi_total += this->hi[i];
		gi2_total += this->gi2[i];
		hi2_total += this->hi2[i];
	}
	// return if height reaches the max value
	if(height >= this->_max_height) {
		std::cout << "shrinkage " << this->_shrinkage << " shrinkage2 " << this->_shrinkage2 << " gi_total " << gi_total << " hi_total " << hi_total << " gi2_total " << gi2_total << " hi2_total " << hi2_total << " lambda " << this->_lambda << " lambda2 " << this->_lambda2 << std::endl;
		this->T[idx].set_wstar(this->_shrinkage * -gi_total / (hi_total + this->_lambda));
		this->T[idx].set_mstar(this->_shrinkage2 * -gi2_total / (hi2_total + this->_lambda2));
		this->T[idx].set_leaf(true);
		this->_obj_penalty += pow(this->_shrinkage * -gi_total / (hi_total + this->_lambda), 2);
		this->_obj_penalty += pow(this->_shrinkage2 * -gi2_total / (hi2_total + this->_lambda2), 2);
		std::cout << "obj_function" << this->_obj_penalty << std::endl;
		if (fabs(this->_obj_penalty) > 1e8) {
			std::cout << "WARNING..." << std::endl;
		}
		return;
	}
	// find the dim and cut that have greatest score
	std::vector<int> ma_dim_openmp(X[0].size(), 0), ma_cut_idx_openmp(X[0].size(), 0);
	std::vector<double> ma_cut_openmp(X[0].size(), 0), ma_gain_openmp(X[0].size(), -1);
	// omp_set_num_threads(8);
#pragma omp parallel for
	for(int i = 0; i < X[0].size(); ++i) {
		// sort the node in range[l, r)
		std::vector<std::pair<double, int> > v; // (value, index)
		for(int j = l; j < r; ++j) {
			v.push_back(std::make_pair(X[this->idx[j]][i], j));
		}
		sort(v.begin(), v.end());
		double gi_left = 0, hi_left = 0, gi2_left = 0, hi2_left = 0;	
		for(int j = 0; j < r - l - 1; j++) {  // split point
			std::pair<double, int> p = v[j];
			gi_left += this->gi[p.second];
			hi_left += this->hi[p.second];
			gi2_left += this->gi2[p.second];
			hi2_left += this->hi2[p.second];
			if(j != r - l - 2 && fabs(v[j].first - v[j + 1].first) < 1e-9) {
				continue;
			}
			double res = 0.5 * (pow(gi_left, 2) / (hi_left + this->_lambda)
							  + pow(gi2_left, 2) / (hi2_left + this->_lambda2)
					          + pow(gi_total-gi_left, 2) / (hi_total - hi_left + this->_lambda)
					          + pow(gi2_total-gi2_left, 2) / (hi2_total - hi2_left + this->_lambda2)
							  - pow(gi_total, 2) / (hi_total + this->_lambda)
							  - pow(gi2_total, 2) / (hi2_total + this->_lambda2))
							  - this->_gamma;
			if(res > 0 && res > ma_gain_openmp[i]) {
				ma_gain_openmp[i] = res;
				ma_dim_openmp[i] = i;
				ma_cut_openmp[i] = (v[j].first + v[j + 1].first) / 2;
				ma_cut_idx_openmp[i] = l + j + 1;
			}
		}
	}
	int select_dim = 0;
	for(int i = 0; i < X[0].size(); ++i) {
		if(ma_gain_openmp[i] > ma_gain_openmp[select_dim]) {
			select_dim = i;
		}
	}
    std::cout << "select dim " << select_dim << " value " << ma_cut_openmp[select_dim] << std::endl;
	ma_gain = ma_gain_openmp[select_dim];
	ma_dim = ma_dim_openmp[select_dim];
	ma_cut = ma_cut_openmp[select_dim];
	ma_cut_idx = ma_cut_idx_openmp[select_dim];
	ma_gain_openmp.clear();
	ma_dim_openmp.clear();
	ma_cut_openmp.clear();
	ma_cut_idx_openmp.clear();
	std::cout << "ma_gain " << ma_gain << " ma_dim " << ma_dim << " ma_cut " << ma_cut << " ma_cut_idx " << ma_cut_idx << std::endl;
	// return if gain nothing
	if(ma_gain < 1e-9) {
		std::cout << "shrinkage " << this->_shrinkage << " shrinkage2 " << this->_shrinkage2 << " gi_total " << gi_total << " hi_total " << hi_total << " gi2_total " << gi2_total << " hi2_total " << hi2_total << " lambda " << this->_lambda << " lambda2 " << this->_lambda2 << std::endl;
		this->T[idx].set_wstar(this->_shrinkage * -gi_total / (hi_total + this->_lambda));
		this->T[idx].set_mstar(this->_shrinkage2 * -gi2_total / (hi2_total + this->_lambda2));
		this->T[idx].set_leaf(true);
		this->_obj_penalty += pow(this->_shrinkage * -gi_total / (hi_total + this->_lambda), 2);
		this->_obj_penalty += pow(this->_shrinkage2 * -gi2_total / (hi2_total + this->_lambda2), 2);
		std::cout << "obj_function" << this->_obj_penalty << std::endl;
		if (fabs(this->_obj_penalty) > 1e8) {
			std::cout << "WARNING..." << std::endl;
		}
		return;
	}
	this->T[idx].set_dim(ma_dim);
	this->T[idx].set_cut(ma_cut);
	std::vector<std::pair<double, int> > v;
	for(int i = l; i < r; ++i) {
		v.push_back(std::make_pair(X[this->idx[i]][ma_dim], i));
	}
	sort(v.begin(), v.end());
	std::vector<int> idx_tmp;
	std::vector<double> gi_tmp, gi2_tmp;
	std::vector<double> hi_tmp, hi2_tmp;
	for(int i = l; i < r; ++i) {
		idx_tmp.push_back(this->idx[v[i - l].second]);
		gi_tmp.push_back(this->gi[v[i - l].second]);
		hi_tmp.push_back(this->hi[v[i - l].second]);
		gi2_tmp.push_back(this->gi2[v[i - l].second]);
		hi2_tmp.push_back(this->hi2[v[i - l].second]);
	}
	for(int i = l; i < r; ++i) {
		this->idx[i] = idx_tmp[i - l];
		this->gi[i] = gi_tmp[i - l];
		this->hi[i] = hi_tmp[i - l];
		this->gi2[i] = gi2_tmp[i - l];
		this->hi2[i] = hi2_tmp[i - l];
	}
	this->T[idx].set_left_idx(this->T.size());
	this->T.push_back(Node(l, ma_cut_idx));
	this->T[idx].set_right_idx(this->T.size());
	this->T.push_back(Node(ma_cut_idx, r));
	// omp_set_num_threads(2);
#pragma omp parallel for
	for(int i = 0; i < 2; ++i) {
		if(i == 0) {
			this->grow(this->T[idx].get_left_idx(), X, Y, height + 1);
		} else {
			this->grow(this->T[idx].get_right_idx(), X, Y, height + 1);
		}
	}
	return;
}

double BT::predict(std::vector<double>& Xi, int idx) const {
	if (this->T[idx].get_leaf()) {
		return this->T[idx].get_wstar();
	}
	int dim = this->T[idx].get_dim();
	double cut = this->T[idx].get_cut();
	int new_idx;
	if (Xi[dim] < cut) {
		new_idx = T[idx].get_left_idx();
	} else {
		new_idx = T[idx].get_right_idx();
	}
	return this->predict(Xi, new_idx);
}

double BT::predict2(std::vector<double>& Xi, int idx) const {
	// To return _mstar
	if (this->T[idx].get_leaf()) {
		return this->T[idx].get_mstar();
	}
	int dim = this->T[idx].get_dim();
	double cut = this->T[idx].get_cut();
	int new_idx;
	if (Xi[dim] < cut) {
		new_idx = T[idx].get_left_idx();
	} else {
		new_idx = T[idx].get_right_idx();
	}
	return this->predict2(Xi, new_idx);
}

double BT::obj_function() const {
	return this->_gamma * this->T.size()
		   + 0.5 * this->_lambda * this->_obj_penalty;
}

class BTForest {
public:
	BTForest() = delete;
	BTForest(int sz, double gamma, double gamma2, double lambda, double lambda2, double alpha, int max_height, int max_height2, std::string loss, std::string deviation, double shrinkage, double shrinkage2):_sz(sz), _gamma(gamma), _gamma2(gamma2), _lambda(lambda), _lambda2(lambda2), _alpha(alpha), _max_height(max_height), _max_height2(max_height2), _loss_function(loss), _deviation_function(deviation), _shrinkage(shrinkage), _shrinkage2(shrinkage2) {}

	//void fit(std::vector<std::vector<double> >& X, std::vector<int>& Y);
	void fit(std::vector<std::vector<double> >& X, std::vector<double>& Y, std::vector<std::vector<double> >& XX, std::vector<double>& YY, int error_ratio);
	double predict(std::vector<double>& Xi) const;
	double predict2(std::vector<double>& Xi) const;
	double obj_function(std::vector<std::vector<double> >& X, std::vector<double>& Y) const;
	double score(std::vector<std::vector<double> >& X, std::vector<double>& Y) const;
	double score_mse(std::vector<std::vector<double> >& X, std::vector<double>& Y) const;
	double error_precision(int error_ratio) const;
    double get_D_hat(int idx) const;
	void save();
	void load();
private:
	int _sz;
	double _gamma, _gamma2, _lambda, _lambda2, _alpha, eps = 1e-6;
	int _max_height, _max_height2;
	double _shrinkage, _shrinkage2;
	std::string _loss_function, _deviation_function;
	std::vector<double> Y_hat, D_hat;
	std::vector<BT> F, F2;
};

//void BTForest::fit(std::vector<std::vector<double> >& X, std::vector<int>& Y) {
void BTForest::fit(std::vector<std::vector<double> >& X, std::vector<double>& Y, std::vector<std::vector<double> >& XX, std::vector<double>& YY, int error_ratio) {
	// initialize Y_hat
	this->Y_hat.clear();
	this->D_hat.clear();
	for(int i = 0; i < X.size(); ++i) {
		this->Y_hat.push_back(0);
		if (this->_deviation_function == "L2") {
			this->D_hat.push_back(1); // TODO how to initial D_hat?
		} else if(this->_deviation_function == "SIGMOID") {
			this->D_hat.push_back(0); // TODO how to initial D_hat?
		}
	}
	// construct _sz trees
	int es_acc_idx = 0, es_mse_idx = 0;
	double es_mse_train = 1e18, es_mse_test = 1e18;
	double es_acc_train = 0, es_acc_test = 0;
	for(int ks = 0; ks < this->_sz; ++ks) {
		std::cout << "Fitting tree " << ks << "..." << std::endl;
		BT bt(this->_gamma, this->_lambda, this->_lambda2, this->_alpha, this->_max_height, this->_loss_function, this->_deviation_function, this->_shrinkage, this->_shrinkage2);
		BT bt2(this->_gamma2, this->_lambda, this->_lambda2, this->_alpha, this->_max_height2, this->_loss_function, this->_deviation_function, this->_shrinkage, this->_shrinkage2);
		bt.fit(X, Y, this->Y_hat, this->D_hat);
		bt2.fit(X, Y, this->Y_hat, this->D_hat);
		this->F.push_back(bt);
		this->F2.push_back(bt2);
		// update Y_hat by adding the new tree's output
		for(int i = 0; i < X.size(); ++i) {
			this->Y_hat[i] += bt.predict(X[i], 0);
			this->D_hat[i] += bt2.predict2(X[i], 0);
			// TODO just want to know if learn sth...
			std::cout << "indivi D_hat i " << i << " D_hat[i] " << this->D_hat[i] << std::endl;
		}
		std::cout << "obj_function " << this->obj_function(X, Y) << std::endl;
		std::cout << "error precision " << this->error_precision(error_ratio) << std::endl;
		double tmp_acc_train = this->score(X, Y), tmp_acc_test = this->score(XX, YY);
		double tmp_mse_train = this->score_mse(X, Y), tmp_mse_test = this->score_mse(XX, YY);
		std::cout << "score_acc " << tmp_acc_train << std::endl;
		std::cout << "score_acc(test) " << tmp_acc_test << std::endl;
		std::cout << "score_mse " << tmp_mse_train << std::endl;
		std::cout << "score_mse(test) " << tmp_mse_test << std::endl;
		if (es_mse_test > tmp_mse_test) {
			es_mse_train = tmp_mse_train;
			es_mse_test = tmp_mse_test;
			es_mse_idx = ks;
		}
		if (es_acc_test < tmp_acc_test) {
			es_acc_train = tmp_acc_train;
			es_acc_test = tmp_acc_test;
			es_acc_idx = ks;
		}
	}
	std::cout << "es_acc_idx " << es_acc_idx << " es_acc_train " << es_acc_train << " es_acc_test " << es_acc_test << std::endl;
	std::cout << "es_mse_idx " << es_mse_idx << " es_mse_train " << es_mse_train << " es_mse_test " << es_mse_test << std::endl;
}

double BTForest::predict(std::vector<double>& Xi) const {
	double res = 0;
	for(int i = 0; i < this->F.size(); ++i) {
		res += F[i].predict(Xi, 0);
	}
	return res;
}

double BTForest::predict2(std::vector<double>& Xi) const {
	double res = 0;
	for(int i = 0; i < this->F.size(); ++i) {
		res += F[i].predict2(Xi, 0);
	}
	return res;
}

double BTForest::obj_function(std::vector<std::vector<double> >& X, std::vector<double>& Y) const {
	// TODO fix here to fit your lose function
	double res = 0;
	if (this->_loss_function == "MSE") {
		// penalty from predict 
		for(int i = 0; i < X.size(); ++i) {
			res += pow(Y[i] - this->Y_hat[i], 2) / (pow(this->D_hat[i], 2) + this->eps);	
			res += this->_alpha * pow(D_hat[i], 2);
		}
		res /= X.size();
		// penalty from tree structure
		for(int i = 0; i < this->F.size(); ++i) {
			res += F[i].obj_function();
		}
	} else if(this->_loss_function == "LOGREG") {
		// penalty from predict 
		for(int i = 0; i < X.size(); ++i) {
			if (this->_deviation_function == "L2") {
				res += log(1 + exp(-Y[i] * Y_hat[i])) / (pow(this->D_hat[i], 2) + this->eps);	
			} else if (this->_deviation_function == "SIGMOID") {
				res += log(1 + exp(-Y[i] * Y_hat[i])) / (1 + this->_alpha * fast_sigmoid(D_hat[i]));	
			}

		}
		res /= X.size();
		std::cout << "res1 " << res << std::endl;
		// penalty from tree structure
		/*
		for(int i = 0; i < this->F.size(); ++i) {
			res += F[i].obj_function();
		}
		*/
		res += F[F.size() - 1].obj_function();
		std::cout << "res2 " << res << std::endl;
	} else {
		std::cout << "[BTForest.obj_function] Something wrong..." << std::endl;
		return -1;
	}
	return res;
}

double BTForest::score(std::vector<std::vector<double> >& X, std::vector<double>& Y) const {
	int acc = 0;
	for(int i = 0; i < X.size(); ++i) {
		if (Y[i] * this->predict(X[i]) > 1e-9) {
			acc += 1;
		}
	}
	return 1. * acc / X.size();
}

double BTForest::score_mse(std::vector<std::vector<double> >& X, std::vector<double>& Y) const {
	double mse = 0;
	for(int i = 0; i < X.size(); ++i) {
        mse += pow(Y[i] - this->predict(X[i]), 2);
	}
	return 1. * mse / X.size();
}

double BTForest::error_precision(int error_ratio) const {
	std::vector<std::pair<double, int> > v;
	for(int i = 0; i < this->D_hat.size(); ++i) {
		v.push_back(std::make_pair(this->D_hat[i], i));
	}
	std::sort(v.rbegin(), v.rend());
	int cnt = 0;
	int sz = static_cast<int>(1. * this->D_hat.size() * error_ratio / 100);
	for(int i = 0; i < sz; ++i) {
		int idx = v[i].second;
		if (idx < sz) {
			cnt += 1;
		}
	}
	return 1. * cnt / sz;
}

double BTForest::get_D_hat(int idx) const {
    return this->D_hat[idx];
}

void BTForest::save() {
	// TODO
}

void BTForest::load() {
	// TODO
}


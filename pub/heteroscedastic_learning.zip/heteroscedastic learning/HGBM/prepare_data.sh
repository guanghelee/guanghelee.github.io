#!/bin/bash

cd ./data/

mkdir breast_cancer
cd breast_cancer
echo 'prepare data breast_cancer'
python3 ../../src/format.py breast_cancer
python3 ../../src/noise.py breast_cancer 0.0 0.0
python3 ../../src/noise.py breast_cancer 0.2 0.2
cd ../
rm -f breast_cancer_*

mkdir diabetis
cd diabetis
echo 'prepare data diabetis'
python3 ../../src/format.py diabetis
python3 ../../src/noise.py diabetis 0.0 0.0
python3 ../../src/noise.py diabetis 0.2 0.2
cd ../
rm -f diabetis_*

mkdir thyroid
cd thyroid
echo 'prepare data thyroid'
python3 ../../src/format.py thyroid
python3 ../../src/noise.py thyroid 0.0 0.0
python3 ../../src/noise.py thyroid 0.2 0.2
cd ../
rm -f thyroid_*

mkdir german
cd german
echo 'prepare data german'
python3 ../../src/format.py german
python3 ../../src/noise.py german 0.0 0.0
python3 ../../src/noise.py german 0.2 0.2
cd ../
rm -f german_*

mkdir heart
cd heart
echo 'prepare data heart'
python3 ../../src/format.py heart
python3 ../../src/noise.py heart 0.0 0.0
python3 ../../src/noise.py heart 0.2 0.2
cd ../
rm -f heart_*

mv abalone abalone_tmp
mkdir abalone
cd abalone
echo 'prepare data abalone'
python3 ../../src/libsvm2plain_regr.py ../abalone_tmp ./abalone.xy 8
python3 ../../src/data_split.py abalone
python3 ../../src/noise_regr.py abalone 0.0
python3 ../../src/noise_regr.py abalone 0.2
cd ../
mv abalone_tmp abalone/abalone

mv housing housing_tmp
mkdir housing
cd housing
echo 'prepare data housing'
python3 ../../src/libsvm2plain_regr.py ../housing_tmp ./housing.xy 13
python3 ../../src/data_split.py housing
python3 ../../src/noise_regr.py housing 0.0
python3 ../../src/noise_regr.py housing 0.2
cd ../
mv housing_tmp housing/housing

mv cpusmall cpusmall_tmp
mkdir cpusmall
cd cpusmall
echo 'prepare data cpusmall'
python3 ../../src/libsvm2plain_regr.py ../cpusmall_tmp ./cpusmall.xy 12
python3 ../../src/data_split.py cpusmall
python3 ../../src/noise_regr.py cpusmall 0.0
python3 ../../src/noise_regr.py cpusmall 0.2
cd ../
mv cpusmall_tmp cpusmall/cpusmall

mv bodyfat bodyfat_tmp
mkdir bodyfat
cd bodyfat
echo 'prepare data bodyfat'
python3 ../../src/libsvm2plain_regr.py ../bodyfat_tmp ./bodyfat.xy 14
python3 ../../src/data_split.py bodyfat
python3 ../../src/noise_regr.py bodyfat 0.0
python3 ../../src/noise_regr.py bodyfat 0.2
cd ../
mv bodyfat_tmp bodyfat/bodyfat

mv pyrim pyrim_tmp
mkdir pyrim
cd pyrim
echo 'prepare data pyrim'
python3 ../../src/libsvm2plain_regr.py ../pyrim_tmp ./pyrim.xy 27
python3 ../../src/data_split.py pyrim
python3 ../../src/noise_regr.py pyrim 0.0
python3 ../../src/noise_regr.py pyrim 0.2
cd ../
mv pyrim_tmp pyrim/pyrim

cd ../



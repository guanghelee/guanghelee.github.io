#!/bin/bash

echo 'run breast_cancer by gbm, noise_rate=0.0'
python3 class/gbm-learn.py breast_cancer 0.0 0.0 acc 0.001 0.001 2 0.1 100 > ./log/exp_gbm_breast_cancer_0.0_0.0
echo 'run breast_cancer by gbm, noise_rate=0.2'
python3 class/gbm-learn.py breast_cancer 0.2 0.2 acc 0.01 0.001 2 0.5 100 > ./log/exp_gbm_breast_cancer_0.2_0.2
echo 'run diabetis by gbm, noise_rate=0.0'
python3 class/gbm-learn.py diabetis 0.0 0.0 acc 0.1 0.001 3 0.05 100 > ./log/exp_gbm_diabetis_0.0_0.0
echo 'run diabetis by gbm, noise_rate=0.2'
python3 class/gbm-learn.py diabetis 0.2 0.2 acc 0.5 0.5 2 0.1 100 > ./log/exp_gbm_diabetis_0.2_0.2
echo 'run thyroid by gbm, noise_rate=0.0'
python3 class/gbm-learn.py thyroid 0.0 0.0 acc 0.1 0.01 2 0.1 100 > ./log/exp_gbm_thyroid_0.0_0.0
echo 'run thyroid by gbm, noise_rate=0.2'
python3 class/gbm-learn.py thyroid 0.2 0.2 acc 0.05 0.01 3 0.5 100 > ./log/exp_gbm_thyroid_0.2_0.2
echo 'run german by gbm, noise_rate=0.0'
python3 class/gbm-learn.py german 0.0 0.0 acc 0.03 0.01 4 0.5 100 > ./log/exp_gbm_german_0.0_0.0
echo 'run german by gbm, noise_rate=0.2'
python3 class/gbm-learn.py german 0.2 0.2 acc 0.1 0.002 4 0.1 100 > ./log/exp_gbm_german_0.2_0.2
echo 'run heart by gbm, noise_rate=0.0'
python3 class/gbm-learn.py heart 0.0 0.0 acc 0.1 0.1 2 0.1 100 > ./log/exp_gbm_heart_0.0_0.0
echo 'run heart by gbm, noise_rate=0.2'
python3 class/gbm-learn.py heart 0.2 0.2 acc 0.05 0.1 5 0.1 100 > ./log/exp_gbm_heart_0.2_0.2

echo 'run breast_cancer bt hgbm, noise_rate=0.0'
python3 class/hgbm-learn.py breast_cancer 0.0 0.0 acc 0.05 0.05 0.01 0.01 20 3 10 0.3 0.5 100 > ./log/exp_hgbm_breast_cancer_0.0_0.0
echo 'run breast_cancer by hgbm, noise_rate=0.2'
python3 class/hgbm-learn.py breast_cancer 0.2 0.2 acc 0.05 0.05 0.1 0.1 50 3 12 0.1 0.5 100 > ./log/exp_hgbm_breast_cancer_0.2_0.2
echo 'run diabetis by hgbm, noise_rate=0.0'
python3 class/hgbm-learn.py diabetis 0.0 0.0 acc 0.08 0.08 0.001 0.001 50 3 15 .1 .1 100 > ./log/exp_hgbm_diabetis_0.0_0.0
echo 'run diabetis by hgbm, noise_rate=0.2'
python3 class/hgbm-learn.py diabetis 0.2 0.2 acc 0.05 0.05 0.1 0.1 50 3 12 0.1 0.5 100 > ./log/exp_hgbm_diabetis_0.2_0.2
echo 'run thyroid by hgbm, noise_rate=0.0'
python3 class/hgbm-learn.py thyroid 0.0 0.0 acc 0.05 0.05 0.04 0.01 20 3 15 0.1 0.1 100 > ./log/exp_hgbm_thyroid_0.0_0.0
echo 'run thyroid by hgbm, noise_rate=0.2'
python3 class/hgbm-learn.py thyroid 0.2 0.2 acc 0.002 0.002 0.002 0.001 70 3 9 0.1 0.1 100 > ./log/exp_hgbm_thyroid_0.2_0.2
echo 'run german by hgbm, noise_rate=0.0'
python3 class/hgbm-learn.py german 0.0 0.0 acc 0.01 0.01 0.02 0.01 50 3 12 0.5 0.1 100 > ./log/exp_hgbm_german_0.0_0.0
echo 'run german by hgbm, noise_rate=0.2'
python3 class/hgbm-learn.py german 0.2 0.2 acc 0.05 0.05 0.005 0.002 30 4 10 0.03 0.1 100 > ./log/exp_hgbm_german_0.2_0.2
echo 'run heart by hgbm, noise_rate=0.0'
python3 class/hgbm-learn.py heart 0.0 0.0 acc 0.1 0.1 0.2 0.05 10 3 10 0.02 0.1 100 > ./log/exp_hgbm_heart_0.0_0.0
echo 'run heart by hgbm, noise_rate=0.2'
python3 class/hgbm-learn.py heart 0.2 0.2 acc 0.1 0.1 0.2 0.1 10 4 15 0.1 0.1 100 > ./log/exp_hgbm_heart_0.2_0.2


Heteroscedastic Gradient Boosting Machine (HGBM) version 1.0
Training gradient boosting machine on classification/regression by heteroscedastic learning.
Please contact r05922007@csie.ntu.edu.tw if you have any question.

This implementation should be used in a linux environment.
The codes are written by C++, python and shell commands.
Dependency: g++, c++11, python3.4, matlab

For those who want to reproduce experiment results in the paper:

The classification part of the experiment is conducted in UCI dataset (using the preprocessed dataset from http://theoval.cmp.uea.ac.uk/matlab/), and regression part is conducted in dataset from LIBSVM datasets (https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/).

1. Compile the code:

	sh compile.sh

2. Download matlab code(benchmarks.mat) and LIBSVM dataset(abalone, housing, cpusmall, bodyfat, pyrim) and put them in forder "data".

3. Data preparation:

	matlab (use matlab to run prepare_data.m)
	> prepare_data
	sh prepare_data.sh

	Here we first use the matlab code to get the pre-processed classification data. Then use prepare_data.sh to process those classification data and regression data downloaded from LIBSVM website. (It will create a folder for each dataset and the original regression data will be moved into its folder) It will also prepare 100 splits for each dataset as data_name[1,100].train and data_name[1,100].test. For data_name[i].train, we add noise to form data_name[i].train.[noise_rate].[noise_rate] or data_name[i].train.[noise_rate].

4. Run the experiment.
 
	sh run_class.sh
	sh run_regr.sh

It will run gbm and hgbm for each dataset. In the folder named "log", there are log files containing score of each split and total average. 

5. Get the performance of a specific dataset. For example, 

	sh result.sh breast_cancer

It will show the mean and the standard deviation of accuracy among 100 splits.





For those who want to use it for general purpose:

For general usage, data format of training and testing data should be prepared as follows (seperated by space),

	label1 data1_feature1 data1_feature2 ... data1_featureN
	label2 data2_feature1 data2_feature2 ... data1_featureN
	... ... ...
 
Each line is a label and the corresponding feature vector.

Data format of generated prediction file: The same as training and testing files

1. Compile the code:

	sh compile.sh

2. For classification problem, you run ./class/gbm-train for GBM or ./class/hgbm-train for HGBM

   ./class/gbm-train {training_data} {iter} {gamma1} {lambda1} {testing_data} {depth1} 0 0 {shrinkage1} | grep final_acc
   ./class/hgbm-train {training_data} {iter} {gamma1} {gamma2} {lambda1} {lambda2} {alpha} {testing_data} {depth1} {depth2} 0 0 {shrinkage1} {shrinkage2} | grep final_acc

It will print two line, one for training accuracy and the other one for testing accuracy.

Arguments:

	{iter}: The amount of trees.
	{gamma1}: coefficient of regularization term about number of node
	{gamma2}: coefficient of regularization term about number of node (hgbm only)
	{lambda1}: coefficient of regularization term about label prediction
	{lambda2}: coefficient of regularization term about deviation estimation (hgbm only)
	{training_data}: path to training file
	{testing_data}: path to testing file
	{depth1}: the maximun depth of label prediction tree
	{depth2}: the maximun depth of deviation estimation tree (hgbm only)
	{shrinkage1}: shrinkage used in label prediction
	{shrinkage2}: shrinkage used in deviation estimation (hgbm only)

3. For regression problem, run ./regr/gbm-train for GBM or ./regr/hgbm-train for HGBM. The format of parameters is the same.


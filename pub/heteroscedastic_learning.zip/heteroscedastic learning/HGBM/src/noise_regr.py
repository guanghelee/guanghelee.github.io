import sys
import argparse
import random
import numpy as np

def std_dev(a):

    avg = sum(a) / len(a)
    return pow(sum((avg - value) ** 2 for value in a) / len(a), 0.5)

def get_args():

    parser = argparse.ArgumentParser(description='add noise to regression label')
    parser.add_argument('dataset', help='dataset name')
    parser.add_argument('noise_rate', type=float,
                        help='noise rate of label')
    #parser.add_argument('deviation_rate', type=float,
    #                    help='range of error size')
    args = parser.parse_args()
    return args

if __name__ == '__main__':

    args = get_args()

    for ks in range(1, 101):

        X = []
        Y = []

        with open(args.dataset + str(ks) + '.train', 'r') as f:
            for line in f:
                tokens = line.split()
                y = float(tokens[0])
                Xi = []
                for i in range(1,len(tokens)):
                    xi = float(tokens[i])
                    Xi.append(xi)
                X.append(Xi)
                Y.append(y)

        noise_rate = args.noise_rate
        # deviation_rate = args.deviation_rate
        deviation_rate = 0.1
        Y_dev = std_dev(Y)

        Idx_flip = random.sample(range(len(X)), int(len(X) * noise_rate))
        Y_noise = Y[:]
        for idx in Idx_flip:
            Y_noise[idx] += np.random.normal(0, deviation_rate * Y_dev)

        w = open(args.dataset + str(ks) + '.train.{0}'.format(noise_rate), 'w')
        for i in range(len(Y_noise)):
            w.write('{0}'.format(Y_noise[i]))
            for j in range(len(X[i])):
                w.write(' {0}'.format(X[i][j]))
            w.write('\n')
        w.close()

import sys
import random

if __name__ == '__main__':

    if (len(sys.argv) != 2):
        print('usage python3 data_split.py {dataset name}')
        exit(-1)

    D = []
    with open(sys.argv[1] + '.xy', 'r') as f:
        for line in f:
            D.append(line)


    TRAIN_RATIO = 0.8

    for ks in range(1, 101):

        random.shuffle(D)

        D_train = []
        D_test = []

        for i in range(len(D)):
            if (i < len(D) * TRAIN_RATIO):
                D_train.append(D[i])
            else:
                D_test.append(D[i])

        with open(sys.argv[1] + str(ks) + '.train', 'w') as f:
            for x in D_train:
                f.write(x)

        with open(sys.argv[1] + str(ks) + '.test', 'w') as f:
            for x in D_test:
                f.write(x)


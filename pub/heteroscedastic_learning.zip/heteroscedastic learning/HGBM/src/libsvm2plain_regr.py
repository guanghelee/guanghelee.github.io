import sys
import random

if (__name__ == '__main__'):

    if(len(sys.argv) != 4):
        print('usage python3 libsvm2plain_regr.py {libsvm-format data} {plain data} {# of dim}')
        exit(-1)

    f = open(sys.argv[1], 'r')
    w = open(sys.argv[2], 'w')
    DIM = int(sys.argv[3])
    X, y = [], []
    D = []

    for line in f:
        D.append(line)

    random.shuffle(D)

    for line in D:
        tokens = line.split()
        # TODO Need to meet the input format
        y.append(float(tokens[0]))
        x = [0 for x in range(DIM)]
        for s in tokens[1:]:
            t = s.split(':')
            key, value = int(t[0]), float(t[1])
            x[key - 1] = value
        X.append(x)
    f.close()

    for i in range(len(X)):
        w.write('{0}'.format(y[i]))
        for j in range(len(X[i])):
            w.write(' {0}'.format(X[i][j]))
        w.write('\n')
    w.close()



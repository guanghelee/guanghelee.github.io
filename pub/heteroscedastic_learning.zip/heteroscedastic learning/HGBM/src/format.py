import sys

if __name__ == '__main__':

    if (len(sys.argv) != 2):
        print('usage: python3 format.py {dataset name}')
        exit(-1)

    for i in range(1, 101):
        w_train = open(sys.argv[1] + str(i) + '.train', 'w')
        w_test = open(sys.argv[1] + str(i) + '.test', 'w')

        D = []
        with open('../' + sys.argv[1] + '_x_train_' + str(i), 'r') as f:
            for line in f:
                if (line[-1] == '\n'):
                    line = line[:-1]
                tokens = line.split(',')
                D.append(tokens)
        with open('../' + sys.argv[1] + '_t_train_' + str(i), 'r') as f:
            cnt = 0
            for line in f:
                tokens = line.split()
                y = int(tokens[0])
                w_train.write('{0}'.format(y))
                for x in D[cnt]:
                    w_train.write(' {0}'.format(x))
                w_train.write('\n')
                cnt += 1

        D = []
        with open('../' + sys.argv[1] + '_x_test_' + str(i), 'r') as f:
            for line in f:
                if (line[-1] == '\n'):
                    line = line[:-1]
                tokens = line.split(',')
                D.append(tokens)
        with open('../' + sys.argv[1] + '_t_test_' + str(i), 'r') as f:
            cnt = 0
            for line in f:
                tokens = line.split()
                y = int(tokens[0])
                w_test.write('{0}'.format(y))
                for x in D[cnt]:
                    w_test.write(' {0}'.format(x))
                w_test.write('\n')
                cnt += 1


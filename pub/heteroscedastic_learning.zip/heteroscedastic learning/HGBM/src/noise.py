import sys
import random

if __name__ == '__main__':

    if (len(sys.argv) != 4):
        print('usage: python noise.py {dataname} {rho_pos} {rho_neg}')
        exit(-1)

    for ks in range(1, 101):
        X = []
        Y = []
        Idx_pos, Idx_neg = [], []
        with open(sys.argv[1] + str(ks) + '.train', 'r') as f:
            line_cnt = 0
            for line in f:
                tokens = line.split()
                y = int(tokens[0])
                Xi = []
                for i in range(1,len(tokens)):
                    xi = float(tokens[i])
                    Xi.append(xi)
                X.append(Xi)
                Y.append(y)
                if (y == 1):
                    Idx_pos.append(line_cnt)
                else:
                    Idx_neg.append(line_cnt)
                line_cnt += 1

        rho_pos = float(sys.argv[2])
        rho_neg = float(sys.argv[3])

        Idx_pos_flip = random.sample(range(len(Idx_pos)), int(len(Idx_pos) * rho_pos))
        Idx_neg_flip = random.sample(range(len(Idx_neg)), int(len(Idx_neg) * rho_neg))

        for idx in Idx_pos_flip:
            Y[Idx_pos[idx]] *= -1
        for idx in Idx_neg_flip:
            Y[Idx_neg[idx]] *= -1

        w = open(sys.argv[1] + str(ks) + '.train.{0}.{1}'.format(sys.argv[2], sys.argv[3]), 'w')
        for i in range(len(Y)):
            w.write('{0}'.format(Y[i]))
            for j in range(len(X[i])):
                w.write(' {0}'.format(X[i][j]))
            w.write('\n')

#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <utility>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <omp.h>


void read_data(std::ifstream& f, std::vector<std::vector<double> >& X, std::vector<double>& Y, int error_ratio) {
	std::string s;
	while(getline(f, s)) {
		std::stringstream ss(s);
		double y;
		double xi;	
		std::vector<double> x;
		ss >> y;
		Y.push_back(y);
		while(ss >> xi) {
			x.push_back(xi);
		}
		X.push_back(x);
	}
	int sz = static_cast<int>(1. * Y.size() * error_ratio / 100);
	for (int i = 0; i < sz; ++i) {
		Y[i] *= -1;
	}
	return;
}

class Node {
public:
	Node() = delete;
	Node(int l, int r):_l(l), _r(r) {}

	int get_left() const { return _l; }
	int get_right() const { return _r; }
	int get_left_idx() const { return _chl; }
	int get_right_idx() const { return _chr; }
	int get_dim() const { return _dim; }
	double get_cut() const { return _cut; }
	double get_wstar() const { return _wstar; }
	bool get_leaf() const { return _leaf; }
	void set_left_idx(int idx) { _chl = idx; }
	void set_right_idx(int idx) { _chr = idx; }
	void set_dim(int dim) { _dim = dim; }
	void set_cut(double cut) { _cut = cut; }
	void set_wstar(double wstar) { _wstar = wstar; }	
	void set_leaf(bool leaf) { _leaf = leaf; }
private:
	int _l, _r, _chl, _chr;
	int _dim;
	double _cut, _wstar;
	bool _leaf = false;
};

class BT {
public:
	BT() = delete;
	BT(double gamma, double lambda, int max_height, std::string loss, double shrinkage):_gamma(gamma), _lambda(lambda), _max_height(max_height), _loss_function(loss), _shrinkage(shrinkage) {}
	
	void fit(std::vector<std::vector<double> >& X, std::vector<double>& Y, std::vector<double>& Y_hat);
	double predict(std::vector<double>& Xi, int idx) const;

	void initial_from_loss_function(std::vector<std::vector<double> >& X, std::vector<double>& Y, std::vector<double>&Y_hat);
	double obj_function() const;
private:
	double _gamma, _lambda;
	double _obj_penalty = 0;
	int _max_height;
	double _shrinkage;
	std::string _loss_function;
	std::vector<Node> T;
	std::vector<int> idx;
	std::vector<double> gi, hi;

	void grow(int idx, std::vector<std::vector<double> >& X, std::vector<double>& Y, int height);
};

void BT::initial_from_loss_function(std::vector<std::vector<double> >& X, std::vector<double>& Y, std::vector<double>& Y_hat) {
	// TODO fix here to fit your lose function
	this->gi.clear();
	this->hi.clear();
	this->idx.clear();
	if (this->_loss_function == "MSE") {
		for(int i = 0; i < X.size(); ++i) {
			this->gi.push_back(2 * (Y_hat[i] - Y[i]));
			this->hi.push_back(2);
			this->idx.push_back(i);
		}
	} else if(this->_loss_function == "LOGREG") {
		for(int i = 0; i < X.size(); ++i) {
			this->gi.push_back(-Y[i] * exp(-Y[i] * Y_hat[i])
					           / (1 + exp(-Y[i] * Y_hat[i])));
			this->hi.push_back(pow(-Y[i], 2) * exp(-Y[i] * Y_hat[i])
							   / pow(1 + exp(-Y[i] * Y_hat[i]), 2));
			this->idx.push_back(i);
		}
	} else {
		std::cout << "[BT.initial_from_loss_function] Something wrong..." << std::endl;
		return;
	}
}

void BT::fit(std::vector<std::vector<double> >& X, std::vector<double>& Y, std::vector<double>& Y_hat) {
	this->initial_from_loss_function(X, Y, Y_hat);
	
	// construct the root node
	this->T.push_back(Node(0, X.size()));
	this->grow(0, X, Y, 0);
	std::cout << "T.size() " << this->T.size() << std::endl;
}

void BT::grow(int idx, std::vector<std::vector<double> >& X, std::vector<double>& Y, int height) {
	if(idx >= T.size()) {
		std::cout << "[BT.grow] index out of T.size()" << std::endl;
		return;
	}
	int l = this->T[idx].get_left();
	int r = this->T[idx].get_right();
	int ma_dim, ma_cut_idx;
	double ma_cut, ma_gain = -1;
	double gi_total = 0, hi_total = 0;
	for(int i = l; i < r; ++i) {
		gi_total += this->gi[i];
		hi_total += this->hi[i];
	}
	// return if height reaches the max value
	if(height >= this->_max_height) {
		this->T[idx].set_wstar(this->_shrinkage * -gi_total / (hi_total + this->_lambda));
		this->T[idx].set_leaf(true);
		this->_obj_penalty += pow(this->_shrinkage * -gi_total / (hi_total + this->_lambda), 2);
		return;
	}
	// find the dim and cut that have greatest score
	std::vector<int> ma_dim_openmp(X[0].size(), 0), ma_cut_idx_openmp(X[0].size(), 0);
	std::vector<double> ma_cut_openmp(X[0].size(), 0), ma_gain_openmp(X[0].size(), -1);
	//omp_set_num_threads(8);
#pragma omp parallel for
	for(int i = 0; i < X[0].size(); ++i) {
		// sort the node in range[l, r)
		std::vector<std::pair<double, int> > v; // (value, index)
		for(int j = l; j < r; ++j) {
			v.push_back(std::make_pair(X[this->idx[j]][i], j));
		}
		sort(v.begin(), v.end());
		double gi_left = 0, hi_left = 0;	
		for(int j = 0; j < r - l - 1; j++) {  // split point
			std::pair<double, int> p = v[j];
			gi_left += this->gi[p.second];
			hi_left += this->hi[p.second];
			if(j != r - l - 2 && fabs(v[j].first - v[j + 1].first) < 1e-9) {
				continue;
			}
			double res = 0.5 * (pow(gi_left, 2) / (hi_left + this->_lambda)
					          + pow(gi_total-gi_left, 2) / (hi_total - hi_left + this->_lambda)
							  - pow(gi_total, 2) / (hi_total + this->_lambda)) - this->_gamma;
			if(res > 0 && res > ma_gain_openmp[i]) {
				ma_gain_openmp[i] = res;
				ma_dim_openmp[i] = i;
				ma_cut_openmp[i] = (v[j].first + v[j + 1].first) / 2;
				ma_cut_idx_openmp[i] = l + j + 1;
			}
		}
	}
	int select_dim = 0;
	for(int i = 0; i < X[0].size(); ++i) {
		if(ma_gain_openmp[i] > ma_gain_openmp[select_dim]) {
			select_dim = i;
		}
	}
    std::cout << "select dim " << select_dim << " value " << ma_cut_openmp[select_dim] << std::endl;
	ma_gain = ma_gain_openmp[select_dim];
	ma_dim = ma_dim_openmp[select_dim];
	ma_cut = ma_cut_openmp[select_dim];
	ma_cut_idx = ma_cut_idx_openmp[select_dim];
	ma_gain_openmp.clear();
	ma_dim_openmp.clear();
	ma_cut_openmp.clear();
	ma_cut_idx_openmp.clear();
	// return if gain nothing
	if(ma_gain < 1e-18) {
		this->T[idx].set_wstar(this->_shrinkage * -gi_total / (hi_total + this->_lambda));
		this->T[idx].set_leaf(true);
		this->_obj_penalty += pow(this->_shrinkage * -gi_total / (hi_total + this->_lambda), 2);
		return;
	}
	this->T[idx].set_dim(ma_dim);
	this->T[idx].set_cut(ma_cut);
	std::vector<std::pair<double, int> > v;
	for(int i = l; i < r; ++i) {
		v.push_back(std::make_pair(X[this->idx[i]][ma_dim], i));
	}
	sort(v.begin(), v.end());
	std::vector<int> idx_tmp;
	std::vector<double> gi_tmp;
	std::vector<double> hi_tmp;
	for(int i = l; i < r; ++i) {
		idx_tmp.push_back(this->idx[v[i - l].second]);
		gi_tmp.push_back(this->gi[v[i - l].second]);
		hi_tmp.push_back(this->hi[v[i - l].second]);
	}
	for(int i = l; i < r; ++i) {
		this->idx[i] = idx_tmp[i - l];
		this->gi[i] = gi_tmp[i - l];
		this->hi[i] = hi_tmp[i - l];
	}
	this->T[idx].set_left_idx(this->T.size());
	this->T.push_back(Node(l, ma_cut_idx));
	this->T[idx].set_right_idx(this->T.size());
	this->T.push_back(Node(ma_cut_idx, r));
	//omp_set_num_threads(2);
#pragma omp parallel for
	for(int i = 0; i < 2; ++i) {
		if(i == 0) {
			this->grow(this->T[idx].get_left_idx(), X, Y, height + 1);
		} else {
			this->grow(this->T[idx].get_right_idx(), X, Y, height + 1);
		}
	}
	return;
}

double BT::predict(std::vector<double>& Xi, int idx) const {
	if (this->T[idx].get_leaf()) {
		return this->T[idx].get_wstar();
	}
	int dim = this->T[idx].get_dim();
	double cut = this->T[idx].get_cut();
	int new_idx;
	if (Xi[dim] < cut) {
		new_idx = T[idx].get_left_idx();
	} else {
		new_idx = T[idx].get_right_idx();
	}
	return this->predict(Xi, new_idx);
}
		
double BT::obj_function() const {
	return this->_gamma * this->T.size()
		   + 0.5 * this->_lambda * this->_obj_penalty;
}

class BTForest {
public:
	BTForest() = delete;
	BTForest(int sz, double gamma, double lambda, int max_height, std::string loss, double shrinkage):_sz(sz), _gamma(gamma), _lambda(lambda), _max_height(max_height), _loss_function(loss), _shrinkage(shrinkage) {}

	void fit(std::vector<std::vector<double> >& X, std::vector<double>& Y, std::vector<std::vector<double> >& XX, std::vector<double>& YY);
	double predict(std::vector<double>& Xi) const;
	double obj_function(std::vector<std::vector<double> >& X, std::vector<double>& Y) const;
	double score(std::vector<std::vector<double> >& X, std::vector<double>& Y) const;
	double score_mse(std::vector<std::vector<double> >& X, std::vector<double>& Y) const;
	void save();
	void load();
private:
	int _sz;
	double _gamma, _lambda;
	int _max_height;
	double _shrinkage;
	std::string _loss_function;
	std::vector<double> Y_hat;
	std::vector<BT> F;
};

void BTForest::fit(std::vector<std::vector<double> >& X, std::vector<double>& Y, std::vector<std::vector<double> >& XX, std::vector<double>& YY) {
	// initialize Y_hat
	this->Y_hat.clear();
	for(int i = 0; i < X.size(); ++i) {
		this->Y_hat.push_back(0);
	}
	// construct _sz trees
	int es_acc_idx = 0, es_mse_idx = 0;
	double es_mse_train = 1e18, es_mse_test = 1e18;
	double es_acc_train = 0, es_acc_test = 0;
	for(int ks = 0; ks < this->_sz; ++ks) {
		std::cout << "Fitting tree " << ks << "..." << std::endl;
		BT bt(this->_gamma, this->_lambda, this->_max_height, this->_loss_function, this->_shrinkage);
		bt.fit(X, Y, this->Y_hat);
		this->F.push_back(bt);
		// update Y_hat by adding the new tree's output
		for(int i = 0; i < X.size(); ++i) {
			this->Y_hat[i] += bt.predict(X[i], 0);
		}
		std::cout << "obj_function " << this->obj_function(X, Y) << std::endl;
		double tmp_acc_train = this->score(X, Y), tmp_acc_test = this->score(XX, YY);
		double tmp_mse_train = this->score_mse(X, Y), tmp_mse_test = this->score_mse(XX, YY);
		std::cout << "score_acc " << tmp_acc_train << std::endl;
		std::cout << "score_acc(test) " << tmp_acc_test << std::endl;
		std::cout << "score_mse " << tmp_mse_train << std::endl;
		std::cout << "score_mse(test) " << tmp_mse_test << std::endl;
		if (es_mse_test > tmp_mse_test) {
			es_mse_train = tmp_mse_train;
			es_mse_test = tmp_mse_test;
			es_mse_idx = ks;
		}
		if (es_acc_test < tmp_acc_test) {
			es_acc_train = tmp_acc_train;
			es_acc_test = tmp_acc_test;
			es_acc_idx = ks;
		}
	}
	std::cout << "es_acc_idx " << es_acc_idx << " es_acc_train " << es_acc_train << " es_acc_test " << es_acc_test << std::endl;
	std::cout << "es_mse_idx " << es_mse_idx << " es_mse_train " << es_mse_train << " es_mse_test " << es_mse_test << std::endl;
}

double BTForest::predict(std::vector<double>& Xi) const {
	double res = 0;
	for(int i = 0; i < this->F.size(); ++i) {
		res += F[i].predict(Xi, 0);
	}
	return res;
}

double BTForest::obj_function(std::vector<std::vector<double> >& X, std::vector<double>& Y) const {
	// TODO fix here to fit your lose function
	double res = 0;
	if (this->_loss_function == "MSE") {
		// penalty from predict 
		for(int i = 0; i < X.size(); ++i) {
			res += pow(Y[i] - this->Y_hat[i], 2);	
		}
		res /= X.size();
		// penalty from tree structure
		for(int i = 0; i < this->F.size(); ++i) {
			res += F[i].obj_function();
		}
	} else if(this->_loss_function == "LOGREG") {
		// penalty from predict 
		for(int i = 0; i < X.size(); ++i) {
			res += log(1 + exp(-Y[i] * Y_hat[i]));	
		}
		// penalty from tree structure
		res /= X.size();
		/*
		for(int i = 0; i < this->F.size(); ++i) {
			res += F[i].obj_function();
		}
		*/
		res += F[F.size() - 1].obj_function();
	} else {
		std::cout << "[BTForest.obj_function] Something wrong..." << std::endl;
		return -1;
	}
	return res;
}

double BTForest::score_mse(std::vector<std::vector<double> >& X, std::vector<double>& Y) const {
	double mse = 0;
	for(int i = 0; i < X.size(); ++i) {
		mse += pow(Y[i] - this->predict(X[i]), 2);
	}
	return mse / X.size();
}

double BTForest::score(std::vector<std::vector<double> >& X, std::vector<double>& Y) const {
	int acc = 0;
	for(int i = 0; i < X.size(); ++i) {
		if (Y[i] * this->predict(X[i]) > 1e-9) {
			acc += 1;
		}
	}
	return 1. * acc / X.size();
}

void BTForest::save() {
	// TODO
}

void BTForest::load() {
	// TODO
}


import os
import sys
import subprocess
from joblib import Parallel, delayed
import multiprocessing
import random
import math

def std_dev(a):

    avg = sum(a) / len(a)
    return pow(sum((avg - value) ** 2 for value in a) / len(a), 0.5)

def generate_5fold(data, rho_pos, rho_neg, number_data):

    for i in range(1, number_data + 1):
        train_data = './data/' + data + '/' + data + str(i) + '.train.{0}.{1}'.format(rho_pos, rho_neg)
        D = []
        with open(train_data, 'r') as f:
            for line in f:
                D.append(line)
            
        #random.shuffle(D)

        fps_train = []
        fps_test = []
        for j in range(5):
            w = open('./tmp/' + data + str(i) + '_{0}_{1}'.format(rho_pos, rho_neg) + '_bt_cv_' + str(j + 1) + '.train', 'w')
            fps_train.append(w)
            w = open('./tmp/' + data + str(i) + '_{0}_{1}'.format(rho_pos, rho_neg) + '_bt_cv_' + str(j + 1) + '.test', 'w')
            fps_test.append(w)

        for j in range(len(D)):
            for k in range(5):
                if (j % 5 == k % 5):
                    fps_test[k].write(D[j])
                else:
                    fps_train[k].write(D[j])

        for j in range(5):
            fps_train[j].close()
            fps_test[j].close()

def remove_5fold(data, rho_pos, rho_neg, number_data):

    for i in range(1, number_data + 1):
            ps = subprocess.Popen('rm -f ./tmp/{0}{1}_{2}_{3}_bt_cv_*'.format(data, i, rho_pos, rho_neg), shell=True)


def processInput(paras, number_data):

    data = paras['data']
    rho_pos = paras['rho_pos']
    rho_neg = paras['rho_neg']
    obj = paras['obj']
    lambda1 = paras['lambda1']
    lrate1 = paras['lrate1']
    depth1 = paras['depth1'] 
    gamma = paras['gamma']

    # calculate the average score of 3 dataset of corss-validation in each iteration
    final_scores = []
    final_iters = []
    
    for i in range(1, number_data + 1):
        scores = [[] for x in range(100)]
        for j in range(5):
            train_data = './tmp/' + data + str(i) + '_{0}_{1}_bt_cv_'.format(rho_pos, rho_neg) + str(j + 1) + '.train'
            valid_data = './tmp/' + data + str(i) + '_{0}_{1}_bt_cv_'.format(rho_pos, rho_neg) + str(j + 1) + '.test'

            ps = subprocess.Popen(('./class/gbm-train', train_data, '100', str(gamma), str(lambda1), valid_data, str(depth1), str(0), str(0), str(lrate1)), stdout=subprocess.PIPE)
            output = subprocess.check_output(('grep', 'score_' + obj + '(test)'), stdin=ps.stdout)
            line = output.decode('ascii')
            lines = line.split('\n')
            if (lines[-1] == ''):
                lines = lines[:-1]

            line_cnt = 0
            for line in lines:
                tokens = line.split()
                scores[line_cnt].append(float(tokens[1]))
                line_cnt += 1
                
        for j in range(100):
            scores[j] = sum(scores[j]) / len(scores[j])

        if  (obj == 'acc'):
            best_score = 0
            best_iter = None
            for j in range(100):
                if (scores[j] > best_score):
                    best_score = scores[j]
                    best_iter = j + 1
        else:
            best_score = 1e18
            best_iter = None
            for j in range(100):
                if (scores[j] < best_score):
                    best_score = scores[j]
                    best_iter = j + 1
        final_scores.append(best_score)
        final_iters.append(best_iter)


    paras['accmse'] = final_scores
    paras['iter'] = final_iters

    return paras


if __name__ == '__main__':

    if (len(sys.argv) != 10):
        print('usage: python3 gbm-learn.py {file} {rho_pos} {rho_neg} {acc|mse} {gamma} {lambda1} {depth1} {lrate1} {# of data}')
        exit(-1)

    print(os.path.dirname(os.path.abspath(__file__)))
    data = sys.argv[1]
    rho_pos = sys.argv[2]
    rho_neg = sys.argv[3]
    obj = sys.argv[4]
    number_data = int(sys.argv[9])

    generate_5fold(data, rho_pos, rho_neg, number_data)

    paras = []
    for gamma in [float(sys.argv[5])]:
        for lambda1 in [float(sys.argv[6])]:
            for depth1 in [int(sys.argv[7])]:
                for lrate1 in [float(sys.argv[8])]:
                    res = {}
                    res['data'] = data
                    res['obj'] = obj
                    res['rho_pos'] = rho_pos
                    res['rho_neg'] = rho_neg
                    res['lambda1'] = lambda1
                    res['lrate1'] = lrate1
                    res['depth1'] = depth1
                    res['gamma'] = gamma
                    paras.append(res)

    num_cores = 4
    results = Parallel(n_jobs=num_cores)(delayed(processInput)(p, number_data) for p in paras)
    #print(processInput(paras[0]))
    print(results)

    provide_scores = []
    provide_paras = []

    for i in range(number_data):
        if (obj == 'acc'):
            best_accmse = 0
        else:
            best_accmse = 1e18
        best_para = None
        for x in results:
            if ((obj == 'acc' and x['accmse'][i] > best_accmse) or (obj == 'mse' and x['accmse'][i] < best_accmse)):
                best_accmse = x['accmse'][i]
                best_para = x
        
        provide_paras.append(best_para)

    for i in range(number_data):
        print(provide_paras[i])
        paras = provide_paras[i]
        train_data = './data/' + data + '/' + data + str(i + 1) + '.train.{0}.{1}'.format(rho_pos, rho_neg)
        test_data = './data/' + data + '/' + data + str(i + 1) + '.test'

        tree_cnt = paras['iter'][i]
        gamma = paras['gamma']
        lambda1 = paras['lambda1']
        depth1 = paras['depth1']
        lrate1 = paras['lrate1']
        ps = subprocess.Popen(('./class/gbm-train', train_data, str(tree_cnt), str(gamma), str(lambda1), test_data, str(depth1), str(0), str(0), str(lrate1)), stdout=subprocess.PIPE)
        output = subprocess.check_output(('grep', 'final_' + obj + '(test)'), stdin=ps.stdout)
        line = output.decode('ascii')
        print(line)

        if (line[-1] == '\n'):
            line = line[:-1]
        tokens = line.split()
        provide_scores.append(float(tokens[1]))
        
    print('total_avg {0}'.format(sum(provide_scores) / len(provide_scores)))
    print('std_dev {0}'.format(std_dev(provide_scores)))

    remove_5fold(data, rho_pos, rho_neg, number_data)

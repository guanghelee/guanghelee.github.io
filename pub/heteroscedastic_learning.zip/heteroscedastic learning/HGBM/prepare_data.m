load('./data/benchmarks.mat')

for i = 1:100,
	dlmwrite(strcat('./data/breast_cancer_x_train_', num2str(i)), breast_cancer.x(breast_cancer.train(i,:),:));
	dlmwrite(strcat('./data/breast_cancer_t_train_', num2str(i)), breast_cancer.t(breast_cancer.train(i,:),:));
	dlmwrite(strcat('./data/breast_cancer_x_test_', num2str(i)), breast_cancer.x(breast_cancer.test(i,:),:));
	dlmwrite(strcat('./data/breast_cancer_t_test_', num2str(i)), breast_cancer.t(breast_cancer.test(i,:),:));

	dlmwrite(strcat('./data/diabetis_x_train_', num2str(i)), diabetis.x(diabetis.train(i,:),:));
	dlmwrite(strcat('./data/diabetis_t_train_', num2str(i)), diabetis.t(diabetis.train(i,:),:));
	dlmwrite(strcat('./data/diabetis_x_test_', num2str(i)), diabetis.x(diabetis.test(i,:),:));
	dlmwrite(strcat('./data/diabetis_t_test_', num2str(i)), diabetis.t(diabetis.test(i,:),:));

	dlmwrite(strcat('./data/thyroid_x_train_', num2str(i)), thyroid.x(thyroid.train(i,:),:));
	dlmwrite(strcat('./data/thyroid_t_train_', num2str(i)), thyroid.t(thyroid.train(i,:),:));
	dlmwrite(strcat('./data/thyroid_x_test_', num2str(i)), thyroid.x(thyroid.test(i,:),:));
	dlmwrite(strcat('./data/thyroid_t_test_', num2str(i)), thyroid.t(thyroid.test(i,:),:));

	dlmwrite(strcat('./data/german_x_train_', num2str(i)), german.x(german.train(i,:),:));
	dlmwrite(strcat('./data/german_t_train_', num2str(i)), german.t(german.train(i,:),:));
	dlmwrite(strcat('./data/german_x_test_', num2str(i)), german.x(german.test(i,:),:));
	dlmwrite(strcat('./data/german_t_test_', num2str(i)), german.t(german.test(i,:),:));

	dlmwrite(strcat('./data/heart_x_train_', num2str(i)), heart.x(heart.train(i,:),:));
	dlmwrite(strcat('./data/heart_t_train_', num2str(i)), heart.t(heart.train(i,:),:));
	dlmwrite(strcat('./data/heart_x_test_', num2str(i)), heart.x(heart.test(i,:),:));
	dlmwrite(strcat('./data/heart_t_test_', num2str(i)), heart.t(heart.test(i,:),:));
end;

#!/bin/bash

echo "gbm on $1, error_rate=0.0"
tail -n 2 "./log/exp_gbm_${1}_"*

echo "\nhgbm on $1, error_rate=0.0"
tail -n 2 "./log/exp_hgbm_${1}_"*

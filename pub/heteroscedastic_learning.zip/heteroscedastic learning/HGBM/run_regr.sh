#!/bin/bash

echo 'run abalone by gbm, noise_rate=0.0'
python3 regr/gbm-learn.py abalone 0.0 0.0 mse 0.2 0.01 4 0.2 100 > ./log/exp_gbm_abalone_0.0_0.0
echo 'run abalone by gbm, noise_rate=0.2'
python3 regr/gbm-learn.py abalone 0.2 0.2 mse 0.05 0.001 3 0.2 100 > ./log/exp_gbm_abalone_0.2_0.2
echo 'run housing by gbm, noise_rate=0.0'
python3 regr/gbm-learn.py housing 0.0 0.0 mse 8 0.1 3 0.05 100 > ./log/exp_gbm_housing_0.0_0.0
echo 'run housing by gbm, noise_rate=0.2'
python3 regr/gbm-learn.py housing 0.2 0.2 mse 8 0.1 3 0.08 100 > ./log/exp_gbm_housing_0.2_0.2
echo 'run cpusmall by gbm, noise_rate=0.0'
python3 regr/gbm-learn.py cpusmall 0.0 0.0 mse 0.05 0.01 4 0.1 100 > ./log/exp_gbm_cpusmall_0.0_0.0
echo 'run cpusmall by gbm, noise_rate=0.2'
python3 regr/gbm-learn.py cpusmall 0.2 0.2 mse 0.01 0.01 4 0.1 100 > ./log/exp_gbm_cpusmall_0.2_0.2
echo 'run bodyfat by gbm, noise_rate=0.0'
python3 regr/gbm-learn.py bodyfat 0.0 0.0 mse 0.01 0.01 4 0.2 100 > ./log/exp_gbm_bodyfat_0.0_0.0
echo 'run bodyfat by gbm, noise_rate=0.2'
python3 regr/gbm-learn.py bodyfat 0.2 0.2 mse 0.01 0.008 5 0.2 100 > ./log/exp_gbm_bodyfat_0.2_0.2
echo 'run pyrim by gbm, noise_rate=0.0'
python3 regr/gbm-learn.py pyrim 0.0 0.0 mse 0.001 0.001 2 0.2 100 > ./log/exp_gbm_pyrim_0.0_0.0
echo 'run pyrim by gbm, noise_rate=0.2'
python3 regr/gbm-learn.py pyrim 0.2 0.2 mse 0.001 0.001 2 0.5 100 > ./log/exp_gbm_pyrim_0.2_0.2

echo 'run abalone by hgbm, noise_rate=0.0'
python3 regr/hgbm-learn.py abalone 0.0 0.0 mse 0.01 0.01 0.01 0.01 50 4 15 0.1 0.1 100 > ./log/exp_hgbm_abalone_0.0_0.0
echo 'run abalone by hgbm, noise_rate=0.2'
python3 regr/hgbm-learn.py abalone 0.2 0.2 mse 0.01 0.01 0.01 0.01 100 3 10 0.1 0.1 100 > ./log/exp_hgbm_abalone_0.2_0.2
echo 'run housing by hgbm, noise_rate=0.0'
python3 regr/hgbm-learn.py housing 0.0 0.0 mse 0.01 0.01 0.01 0.01 50 3 15 0.08 0.5 100 > ./log/exp_hgbm_housing_0.0_0.0
echo 'run housing by hgbm, noise_rate=0.2'
python3 regr/hgbm-learn.py housing 0.2 0.2 mse 0.03 0.03 0.02 0.01 8 3 15 0.1 0.1 100 > ./log/exp_hgbm_housing_0.2_0.2
echo 'run cpusmall by hgbm, noise_rate=0.0'
python3 regr/hgbm-learn.py cpusmall 0.0 0.0 mse 0.01 0.01 0.01 0.01 10 4 15 0.1 0.1 100 > ./log/exp_hgbm_cpusmall_0.0_0.0
echo 'run cpusmall by hgbm, noise_rate=0.2'
python3 regr/hgbm-learn.py cpusmall 0.2 0.2 mse 0.02 0.02 0.01 0.01 10 5 15 0.2 0.08 100 > ./log/exp_hgbm_cpusmall_0.2_0.2
echo 'run bodyfat by hgbm, noise_rate=0.0'
python3 regr/hgbm-learn.py bodyfat 0.0 0.0 mse 0.001 0.001 0.005 0.001 10 4 8 0.5 0.1 100 > ./log/exp_hgbm_bodyfat_0.0_0.0
echo 'run bodyfat by hgbm, noise_rate=0.2'
python3 regr/hgbm-learn.py bodyfat 0.2 0.2 mse 0.001 0.001 0.001 0.001 10 3 8 0.5 0.2 100 > ./log/exp_hgbm_bodyfat_0.2_0.2
echo 'run pyrim by hgbm, noise_rate=0.0'
python3 regr/hgbm-learn.py pyrim 0.0 0.0 mse 0.001 0.001 0.005 0.005 10 4 10 0.3 0.1 100 > ./log/exp_hgbm_pyrim_0.0_0.0
echo 'run pyrim by hgbm, noise_rate=0.2'
python3 regr/hgbm-learn.py pyrim 0.2 0.2 mse 0.001 0.001 0.004 0.004 10 4 10 0.3 0.1 100 > ./log/exp_hgbm_pyrim_0.2_0.2


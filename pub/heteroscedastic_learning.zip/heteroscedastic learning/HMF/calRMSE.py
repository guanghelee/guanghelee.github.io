import sys
from numpy import sqrt
def RMSE(A,B):
	mse = 0.
	count = 0.
	with open(A) as afp, open(B) as bfp:
		for line in afp:
			a = line.strip().split(' ')[-1]
			line = bfp.readline()
			b = line.strip().split(' ')[-1]
			a = float(a)
			b = float(b)
			mse+=(a-b)**2
			count+=1
	print sqrt(mse/count)
			

A = sys.argv[1]
B = sys.argv[2]

RMSE(A,B)
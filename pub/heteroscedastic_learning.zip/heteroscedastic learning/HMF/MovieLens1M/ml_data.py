from random import shuffle
from collections import defaultdict

def dump(data,fp):
	for i in data:
		fp.write(i+' '+str(len(data[i]))+'\n')
		for rating in data[i]:
			fp.write(rating+' ')
		fp.write('\n')

user = set()
item = set()
records = []

with open('ratings.dat') as fp:
	for line in fp:
		line = line.strip().split('::')
		user.add(int(line[0]))
		item.add(int(line[1]))
		records.append(line[:3])

print len(records), 'records'
print len(user),'users' #943 users
print len(item),'items' #1682 items
print 'sparsity',1-float(len(records))/(len(user)*len(item))
print 'min/max user',min(user),max(user)
print 'min/max item',min(item),max(item)

for t in xrange(5):	
	with open('train.'+str(t)+'.dat','w') as trainfp,open('valid.'+str(t)+'.dat','w') as validfp,open('test.'+str(t)+'.dat','w') as testfp:
		shuffle(records)
		train = dict()
		valid = dict()
		test = dict()
		for i in xrange(len(records)):
			if i < 0.1*len(records): # test
				testfp.write(str(records[i][0])+' '+str(records[i][1])+' '+str(records[i][2])+'\n')
			elif i < 0.91*len(records): # train
				trainfp.write(str(records[i][0])+' '+str(records[i][1])+' '+str(records[i][2])+'\n')
			else:
				validfp.write(str(records[i][0])+' '+str(records[i][1])+' '+str(records[i][2])+'\n')


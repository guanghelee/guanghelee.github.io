#!/bin/sh
#for c in $(seq 1 100)
#do
for version in 0 1 2 3 4
do
        ../hmf -train train.$version.dat valid.$version.dat -1 -test test.$version.dat -ite 20 -D 100 -sigma_U 0.15 -sigma_V 0.2 -sigma 0.01 -lbda_P 0.75 -lbda_Q 0.75 -lr_method 2 -lr 0.05 -log log/hmf.$version -time_log log/hmf.time.$version # -v -lr_curve log/hmf.$version.lr_curve -pred prediction/hmf.$version.pred
done
#done

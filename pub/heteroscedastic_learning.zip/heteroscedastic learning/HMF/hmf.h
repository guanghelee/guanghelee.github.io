#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <vector>
#include <ctime>
#include <assert.h>
#include <cmath>
#include <algorithm>
#include <string>
#include <unistd.h>
#include <omp.h>
#include <set>
#include <pthread.h>
#include <random>
using namespace std;

class Mat{
public:
	int u;
	int v;
	double r;
	Mat(){}
	Mat(int a,int b,double c){
		u = a;	v = b;	r = c;
	}
};

vector<int> shape;
vector<char*> trainFile;
char* testFile;
int D;
int M; // # of users, i.e. feature
int N; // # of items, 
int ite; // iteration number
int batchSize;
double lr = 0.01;
double moment;
//double* activation;
double sigma_u = 0.01;
double sigma_v = 0.01;

double lbda_p = 0.01;
double lbda_q = 0.01;
double l1 = 0.01;
double sigma = 0.01;

char* config = NULL;
int lr_method = -1;
vector<Mat> trainData, testData;
set<int> userSet, itemSet;
int trainCount, testCount;
double **U, **V; // encoder, decoder
double **P, **Q;
bool sigmoid = false;
bool exp_init = false;

pthread_mutex_t *lockU,*lockV;

double **accU, **accV; // encoder, decoder
double **accP, **accQ;

//double **mU, **mV; // encoder, decoder
//double **mP, **mQ;

double *alpha, *beta;
double *accAlpha, *accBeta;
//double *mAlpha, *mBeta;

double trainMean;
double variance;

double offset = 3;
 
FILE* hisfp = NULL;
FILE* timefp = NULL;
FILE* logfp = NULL;
FILE* predfp = NULL;

bool validation = false;

double *var_bar_train;
double *mse_bar_train;
double *buff_var_train;
double *buff_mse_train;

double *var_bar_test;
double *mse_bar_test;
double *buff_var_test;
double *buff_mse_test;
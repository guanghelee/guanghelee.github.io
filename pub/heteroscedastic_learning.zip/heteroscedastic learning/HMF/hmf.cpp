#include <cstdio>
#include <vector>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <ctime>
#include <omp.h>
#include <random>
#include <pthread.h>
#include <assert.h>
#include "hmf.h"
#include <unistd.h>
#include <parallel/algorithm>
using namespace std;

#define THREAD_N 200

inline double g(double x){
	return 1./(1+exp(-x));
}
double dg(double x){
	double y = g(x);
	return y*(1-y);
}
inline double sqr(double x){
	return x*x;
}
void dump(char fname[100],double** &W, int &M, int &D){
	FILE* fp = fopen(fname,"w");
	fprintf(fp,"%d %d\n",M,D);
	for(int i=0;i<M;i++){
		for(int k=0;k<D;k++)
			fprintf(fp,"%lf ",W[i][k]);
		fprintf(fp,"\n");
	}
}
void dumpModel(char *config){
	char U1[100]={0};
	char U2[100]={0};
	char V1[100]={0};
	char V2[100]={0};
	strcpy(U1,config);
	strcpy(U2,config);
	strcpy(V1,config);
	strcpy(V2,config);
	strcat(U1,".U1");
	strcat(U2,".U2");
	strcat(V1,".V1");
	strcat(V2,".V2");
	dump(U1,U,M,D);
	dump(U2,V,N,D);
	dump(V1,P,M,D);
	dump(V2,Q,N,D);
}
void predToFile(FILE* predfp){
	int u;
	int v;
	int n;
	double rating;
	FILE* testfp = fopen(testFile,"r");
	int line = 0;
	while(fscanf(testfp,"%d%d%lf",&u,&v,&rating)!=EOF){
		if(userSet.find(u)==userSet.end()||itemSet.find(v)==itemSet.end()){
			fprintf(predfp,"%d %d 3\n",u,v);
			continue;
		}
		
		double pred = 0.;
		for(int k=0;k<D;k++)
			pred+=U[u][k]*V[v][k];
		pred += (alpha[u]+beta[v]+trainMean);
		fprintf(predfp,"%d %d %lf\n",u,v,pred);
	}
	fclose(testfp);
	fclose(predfp);
	return;
}
void readFile(char* fileName, vector<Mat> &data,int &count){
	int userId;
	int itemId;
	int n;
	double rating;
	FILE* fp = fopen(fileName,"r");
	int line = 0;
	while(fscanf(fp,"%d%d%lf",&userId,&itemId,&rating)!=EOF){
		N = (N>itemId) ? N : itemId;
		M = (M>userId) ? M : userId;
		data.push_back(Mat(userId,itemId,rating));
		count++;
		line++;
		if(line%100000==0)
			printf("reading %d\n",line);
	}
	fclose(fp);
	return;
}
double rankcor(double* a,double* b,double* c,double* d,int len){
//	puts("in");
//	double c[len];
//	double d[len];
#pragma parallel for nowait
	for(int i=0;i<len;i++)
		c[i] = a[i];
#pragma parallel for
	for(int i=0;i<len;i++)
		d[i] = b[i];
//puts("in2");

	__gnu_parallel::sort(c, c+len);
	__gnu_parallel::sort(d, d+len);
//puts("in3");
	//sort(c.begin(),c.end());
	//sort(d.begin(),d.end());
	map<double,double> positionA;
	map<double,double> positionB;

#pragma omp parallel sections
{
#pragma omp section
{
	pair<int,double> last;
	last.first = 0;
	last.second = c[0];
	
	for(int i=0;i<len;i++){
		if(last.second!=c[i]){
			positionA[last.second] = double(last.first+i-1)/2 + 1;
			last.first = i;
			last.second = c[i];
		}
	}
	positionA[last.second] = double(last.first+len-1)/2 + 1;
}
#pragma omp section
{
	pair<int,double> last;	
	last.first = 0;
	last.second = d[0];
	for(int i=0;i<len;i++){
		if(last.second!=d[i]){
			positionB[last.second] = double(last.first+i-1)/2 + 1;
			last.first = i;
			last.second = d[i];
		}
	}
	positionB[last.second] = double(last.first+len-1)/2 + 1;
}
}
    double cor = 0;
#pragma omp parallel for reduction(+:cor)
	for(int i=0;i<len;i++){
		double pa = positionA[a[i]];
		double pb = positionB[b[i]];
		cor+=sqr(pa-pb);
	}
	cor*=6;
	cor/=len;
	cor/=(sqr(len)-1);
    return 1-cor;
}
/*double rankcor(vector<double> &a,vector<double> &b){
	vector<double> c;
	vector<double> d;
	for(int i=0;i<a.size();i++)	c.push_back(a[i]);
	for(int i=0;i<b.size();i++)	d.push_back(b[i]);
	sort(c.begin(),c.end());
	sort(d.begin(),d.end());
	map<double,double> positionA;
	map<double,double> positionB;
	
	pair<int,double> last;
	last.first = 0;
	last.second = c[0];
	
	for(int i=0;i<c.size();i++){
		if(last.second!=c[i]){
			positionA[last.second] = double(last.first+i-1)/2 + 1;
			last.first = i;
			last.second = c[i];
		}
	}
	positionA[last.second] = double(last.first+c.size()-1)/2 + 1;
	
	last.first = 0;
	last.second = d[0];
	for(int i=0;i<d.size();i++){
		if(last.second!=d[i]){
			positionB[last.second] = double(last.first+i-1)/2 + 1;
			last.first = i;
			last.second = d[i];
		}
	}
	positionB[last.second] = double(last.first+d.size()-1)/2 + 1;
	
    double cor = 0;
#pragma omp parallel for reduction(+:cor)
	for(int i=0;i<a.size();i++){
		double pa = positionA[a[i]];
		double pb = positionB[b[i]];
		cor+=sqr(pa-pb);
	}
	cor*=6;
	cor/=a.size();
	cor/=(sqr(a.size())-1);
    return 1-cor;
}*/
void readInput(int argc,char* argv[]){	// trainFile, testFile, lr_method, config, l2, lr, ite, D
	for(int i=0;i<argc;i++){
		if(!strcmp(argv[i],"-train")){
			while(strcmp(argv[i+1],"-1")){
				trainFile.push_back(argv[++i]);
				printf("use data %s for training...\n",argv[i]);
			}
		}if(!strcmp(argv[i],"-sigmoid")){
			sigmoid=true;
		}if(!strcmp(argv[i],"-D")){
			D = atoi(argv[i+1]);
			printf("dimension = %d\n",D);
		}if(!strcmp(argv[i],"-batch")){
			batchSize = atoi(argv[i+1]);
			printf("batchSize = %d\n",batchSize);
		}if(!strcmp(argv[i],"-ite")){
			ite = atoi(argv[i+1]);
			printf("training iteration = %d\n",ite);
		}if(!strcmp(argv[i],"-lr")){
			lr = atof(argv[i+1]);
			printf("learning rate = %lf\n",lr);
		}if(!strcmp(argv[i],"-moment")){
			moment = atof(argv[i+1]);
			printf("momentum = %lf\n",moment);
		}if(!strcmp(argv[i],"-sigma_U")){
			sigma_u = atof(argv[i+1]);
			printf("sigma_U regularization = %lf\n",sigma_u);
		}if(!strcmp(argv[i],"-sigma_V")){
			sigma_v = atof(argv[i+1]);
			printf("sigma_V regularization = %lf\n",sigma_v);
		}if(!strcmp(argv[i],"-lbda_P")){
			lbda_p = atof(argv[i+1]);
			printf("lbda_P regularization = %lf\n",lbda_p);
		}if(!strcmp(argv[i],"-lbda_Q")){
			lbda_q = atof(argv[i+1]);
			printf("lbda_Q regularization = %lf\n",lbda_q);
		}if(!strcmp(argv[i],"-model")){
			config = argv[i+1];
			printf("model file = %s\n",config);
		}if(!strcmp(argv[i],"-lr_method")){
			lr_method = atoi(argv[i+1]);
			if(lr_method == 0)	puts("simple sgd");
			if(lr_method == 1)	puts("Rprop");
			if(lr_method == 2)	puts("AdaGrad");
		}if(!strcmp(argv[i],"-test")){
			testFile = argv[i+1];
		}if(!strcmp(argv[i],"-sigma")){
			sigma = atof(argv[i+1]);
		}if(!strcmp(argv[i],"-lr_curve")){
			hisfp = fopen(argv[i+1],"w");
		}if(!strcmp(argv[i],"-log")){
			logfp = fopen(argv[i+1],"a");
		}if(!strcmp(argv[i],"-v")){
            validation = true;
		}if(!strcmp(argv[i],"-time_log")){
			timefp = fopen(argv[i+1],"a");
		}if(!strcmp(argv[i],"-pred")){
			predfp = fopen(argv[i+1],"w");
		}if(!strcmp(argv[i],"-offset")){
			if(!strcmp(argv[i+1],"exp")){
				exp_init = true;
				puts("exp init");
			}else
				offset = atof(argv[i+1]);
		}
		/*if(!strcmp(argv[i],"-log")){
			logFile = (argv[i+1]);
		}if(!strcmp(argv[i],"-v")){
            validation = true;
		}if(!strcmp(argv[i],"-auto")){
            autoControl = true;
		}if(!strcmp(argv[i],"-cor_log")){
			corfp = fopen(argv[i+1],"a");
		}if(!strcmp(argv[i],"-time_log"))
			timefp = fopen(argv[i+1],"a");
		*/
	}
}


void initialize(double** &W, int &M, int &D,int fill){
	default_random_engine generator;
	exponential_distribution<double> distribution(lbda_p);
	W = new double*[M];
	for (int i = 0; i < M; ++i){
		W[i] = new double[D]();
		if(fill==0)
			continue;
		else if(fill==1)
			for(int j=0;j<D;j++)
				W[i][j] = 0.5 * (1 - 2*(double) rand() / (RAND_MAX));
		else if(fill==2)
			for(int j=0;j<D;j++){
				if(exp_init)
					W[i][j] = distribution(generator);
				else
					W[i][j] = offset+1*((double) rand() / (RAND_MAX));
			}	
	}
}
int sign(double a){
	if(a==0)	return 0;
	else if(a>0) return 1;
	else return -1;
}
void update_param(double &deri, double &last_deri, double &acc_lr, double &param){
	//printf("%lf, %lf\n",deri,param);
	if(lr_method==2){
		last_deri += sqr(deri);
		param -= lr * deri/sqrt(last_deri);
	}else if(lr_method==0){
		param -= lr * deri;
	}else if(lr_method==1){
		int current = sign(deri);
		int last = int(last_deri);
		last_deri = current;
		if(current==0)
			return;
		else if(current == last)
			acc_lr *= 1.2;
		else
			acc_lr *= 0.5;
		param -= current * acc_lr;
	}else{
		printf("no lr method %d\n", lr_method);
	}
}

//update_param
double norm(double** matrix){
	double n =0;
#pragma omp parallel for reduction(+:n)
	for(int i=0;i<M;i++)
		for(int j=0;j<D;j++)
			n+=sqr(matrix[i][j]);
	return sqrt(n);
}
double normVec(double* vec, int len){
	double n =0;
#pragma omp parallel for reduction(+:n)
	for(int i=0;i<len;i++)
		n+=sqr(vec[i]);
	return sqrt(n);
}
void refresh(double** dU, double** dV, double** dP, double** dQ,double x=0){
//#pragma omp parallel for schedule(guided,1)
	for(int i=0;i<M;i++)
		fill_n(dU[i],D,x);
	for(int i=0;i<M;i++)
		fill_n(dP[i],D,x);
	for(int i=0;i<N;i++)
		fill_n(dV[i],D,x);
	for(int i=0;i<N;i++)
		fill_n(dQ[i],D,x);
	//fill_n(dAlpha,D,x);
	//fill_n(dBeta,M,x);
	//fill_n(dGama,M,x);
}
void update_param_sgd(double &deri, double &acc_lr, double &param){
	//printf("%lf, %lf\n",deri,param);
	if(lr_method==2){
		acc_lr += sqr(deri);
		param -= lr * deri/sqrt(acc_lr);
	}else if(lr_method==0){
		param -= lr * deri;
	}else{
		printf("no lr method %d\n", lr_method);
	}
}
void sgd(int &u, int &v, double &r){
	//puts("in");
	double ybar = 0;
	for(int i=0;i<D;i++)
		ybar += U[u][i] * V[v][i];
	ybar += (alpha[u]+beta[v]);
	double diff;
	if(!sigmoid)
		diff = ybar - r;
	else	// (ybar - 4*)
		diff = (g(ybar) * 4 - r * 4) * dg(ybar);
	double var = 0;
	for(int i=0;i<D;i++)
		var += P[u][i] * Q[v][i];
	var += sigma;
	var = 1/var;

	for(int k=0;k<D;k++){
		double deri = diff * var * U[u][k] + sigma_v * V[v][k];
		update_param_sgd(deri,accV[v][k],V[v][k]);
	}
	for(int k=0;k<D;k++){
		double deri = diff * var * V[v][k] + sigma_u * U[u][k];
		update_param_sgd(deri,accU[u][k],U[u][k]);
	}
	//double dAlpha = diff * var + sigma_u * alpha[u];
	double dAlpha = diff * var;
	update_param_sgd(dAlpha,accAlpha[u],alpha[u]);
	//double dBeta = diff * var + sigma_v * beta[v];
	double dBeta = diff * var;
	update_param_sgd(dBeta,accBeta[v],beta[v]);
	
	//double sqrVar = sqr(var);
	//diff = sqr(diff);
	if(sigmoid)
		diff = (g(ybar) * 4 - r * 4);
	diff =  -0.5 * (sqr(diff) * sqr(var) - var );
	for(int k=0;k<D;k++){
		double deri = diff * P[u][k] + lbda_q;
		update_param_sgd(deri,accQ[v][k],Q[v][k]);
		if(Q[v][k]<0)	Q[v][k] = 0;
	}
	for(int k=0;k<D;k++){
		double deri = diff * Q[v][k] + lbda_p;
		update_param_sgd(deri,accP[u][k],P[u][k]);
		if(P[u][k]<0)	P[u][k] = 0;
	}	
}

void *batchSgd(void *thread_order){
	vector<int> order = *(vector<int> *)thread_order;
	for(int i=0;i<order.size();i++){
		pthread_mutex_lock(&lockU[trainData[order[i]].u]);
		pthread_mutex_lock(&lockV[trainData[order[i]].v]);
		sgd(trainData[order[i]].u,trainData[order[i]].v,trainData[order[i]].r);
		pthread_mutex_unlock(&lockU[trainData[order[i]].u]);
		pthread_mutex_unlock(&lockV[trainData[order[i]].v]);
	}
	pthread_exit(NULL);
}
double sparsity(){
	int total = 0;
	int available = 0;
#pragma omp parallel for reduction(+:total,available)
	for(int i=0;i<M;i++){
		if(userSet.find(i)==userSet.end())
			continue;
		for(int k=0;k<D;k++)
			if(P[i][k] > 0)
				available++;
		total+=D;
	}
	for(int i=0;i<N;i++){
		if(itemSet.find(i)==itemSet.end())
			continue;
		for(int k=0;k<D;k++)
			if(Q[i][k] > 0)
				available++;
		total+=D;
	}
	return double(available) / double(total);
}
int main(int argc, char *argv[]){
	//omp_set_num_threads(5);
	srand(time(NULL));
	//default_random_engine generator;
	//normal_distribution<double> distribution(0.0,0.01);

	//for(int i=0;i<10;i++)
	//	printf("%.4lf ",distribution(generator));
	//puts("");
	readInput(argc,argv);

	for(int i=0;i<trainFile.size();i++)
		readFile(trainFile[i],trainData,trainCount);
	readFile(testFile,testData,testCount);
/*
	map<int,vector<pair<int,double> > >::iterator it;
	for(it=trainData.begin();it!=trainData.end();++it){
		itemSet.insert(it->first);
		vector<pair<int,double> > &user_rating = it->second;
		for(int i=0;i<user_rating.size();i++)
			userSet.insert(user_rating[i].first);
	}
*/
	for(int i=0;i<trainCount;i++){
		itemSet.insert(trainData[i].v);
		userSet.insert(trainData[i].u);
	}

	M++;
	N++;
	printf("training have %d records\n",trainCount);
	printf("testing  have %d records\n",testCount);
	printf("max userid: %d, max item id: %d\n",M-1,N-1);
	printf("actual number of users: %d, actual number of items: %d\n",userSet.size(),itemSet.size());
	
	initialize(U,M,D,1);
	initialize(V,N,D,1);
	initialize(P,M,D,2);
	initialize(Q,N,D,2);

	alpha = new double[M]();
	beta = new double[N]();
	
	initialize(accU,M,D,0);
	initialize(accV,N,D,0);
	initialize(accP,M,D,0);
	initialize(accQ,N,D,0);
	
	accAlpha = new double[M]();
	accBeta = new double[N]();
	//accGama = new double[M];
	//refresh(accU,accV,accW,accAlpha,accBeta,accGama,0.1);	// learning rate
	//refresh(accU,accV,accP,accQ,0.1);

//	omp_set_num_threads(THREAD_N);
	int batchCount = 0;
	if(batchSize==-1)
		batchSize = trainCount;
	printf("batch size = %d\n",batchSize);
	

	
	if(!sigmoid){
		for(int i=0;i<trainCount;i++)
			trainMean+=trainData[i].r;
		trainMean/=trainCount;
#pragma omp parallel for
		for(int i=0;i<trainCount;i++){
			//printf("%lf %lf\n",trainData[i].r,trainMean);
			trainData[i].r-=trainMean;
		}
#pragma omp parallel for
		for(int i=0;i<testCount;i++)
			testData[i].r-=trainMean;
	}else{	// sigmoid
		for(int i=0;i<trainCount;i++)
			trainData[i].r = (trainData[i].r-1)/4;
		for(int i=0;i<testCount;i++)
			testData[i].r = (testData[i].r-1)/4;

	}
//#pragma omp parallel for
//	for(int i=0;i<THREAD_N;i++)
//		refresh(DU[i],DV[i],DP[i],DQ[i]);
//	refresh(dU,dV,dP,dQ);


	pthread_t threads[THREAD_N];
	lockU = new pthread_mutex_t[M];
	for(int i=0;i<M;i++)
		pthread_mutex_init(&lockU[i], NULL);
	lockV = new pthread_mutex_t[N];
	for(int i=0;i<N;i++)
		pthread_mutex_init(&lockV[i], NULL);	
	
	time_t start,end;
    time(&start);
    var_bar_train = new double[trainData.size()];
	mse_bar_train = new double[trainData.size()];
	buff_var_train = new double[trainData.size()];
	buff_mse_train = new double[trainData.size()];
	
	var_bar_test = new double[testData.size()];
	mse_bar_test = new double[testData.size()];
	buff_var_test = new double[testData.size()];
	buff_mse_test = new double[testData.size()];


	for(int t=0;t<ite;t++){
		printf("epoch %d\n",t);
		//random_shuffle(order,order+trainCount);
		vector<int> thread_order[THREAD_N];
		for(int i=0;i<trainCount;i++)
			thread_order[rand()%THREAD_N].push_back(i);
			//thread_order[i%THREAD_N].push_back(i);
		
//pthread
		for(int i=0;i<THREAD_N;i++){
			int error = pthread_create(&threads[i], NULL, batchSgd, (void *)(&thread_order[i]));
   			assert(error == 0);
		}
		for (int i = 0; i < THREAD_N; i++) 
 			pthread_join(threads[i], NULL);

// openmp mode
/*
#pragma omp parallel for		
		for (int i = 0; i < batchSize; ++i){
//			int id=0;
			int id = omp_get_thread_num();
			calculate_grad(trainData[order[(i+batchCount)%trainData.size()]],DU[id],DV[id]);
		}
		batchCount+=batchSize;
		for(int t=0;t<THREAD_N;t++){
			for(int i=0;i<M;i++)
				for(int j=0;j<D;j++)
					dU[i][j] += DU[t][i][j];
			for(int i=0;i<N;i++)
				for(int j=0;j<D;j++)
					dV[i][j] += DV[t][i][j];
		}
		update_grad(dU,dV);

#pragma omp parallel for
		for(int i=0;i<THREAD_N;i++)
			refresh(DU[i],DV[i],DP[i],DQ[i]);
		refresh(dU,dV,dP,dQ);
		if(batchCount%10000==0)
			printf("%d/%d\n",batchCount,trainCount);
		if(batchCount < trainData.size()){
			t--;
			continue;
		}else
			batchCount -= trainData.size();
*/
		if(!validation)
			continue;
		double MSE = 0;
		double totalVar;
		//puts("1");
		//double var_bar_train[trainData.size()];
		//double mse_bar_train[trainData.size()];
		//puts("2");
		
#pragma omp parallel for reduction(+:totalVar,MSE)
		for (int i = 0; i < trainData.size(); ++i){
			double ybar = 0;
			int u = trainData[i].u;
			int v = trainData[i].v;
			double r = trainData[i].r;
			for(int k=0;k<D;k++)
				ybar+=U[u][k]*V[v][k];
			ybar += (alpha[u]+beta[v]);

			double var = 0;
			for(int k=0;k<D;k++)
				var+=P[u][k]*Q[v][k];
			totalVar+=var;
			double temp_mse;
			if(!sigmoid)
				temp_mse = sqr(ybar-r);
			else
				temp_mse = sqr((g(ybar)-r)*4);
			MSE+=temp_mse;
			
			if(hisfp){
				mse_bar_train[i] = temp_mse;
				var_bar_train[i] = var;
			}
		}
		printf("training error = %lf\n", sqrt(MSE/trainCount));
		printf("average training var = %lf\n",totalVar/trainCount);
		if(hisfp)
			fprintf(hisfp,"%lf %lf %lf ",sqrt(MSE/trainCount),totalVar/trainCount,rankcor(var_bar_train,mse_bar_train,buff_var_train,buff_mse_train,trainData.size()));
		//printf("cor = %lf\n",rankcor(var_bar_train,mse_bar_train));
		totalVar = 0;
		MSE = 0;
		//double var_bar[testData.size()];
		//double mse_bar[testData.size()];
		
#pragma omp parallel for reduction(+:totalVar,MSE)
		for (int i = 0; i < testData.size(); ++i){
			double ybar = 0;
			int u = testData[i].u;
			int v = testData[i].v;
			double r = testData[i].r;
			if(userSet.find(u)==userSet.end()||itemSet.find(v)==itemSet.end()){
				MSE+=sqr(r+trainMean-3);
				mse_bar_test[i] = sqr(r+trainMean-3);
				var_bar_test[i] = 0;
				continue;
			}

			for(int k=0;k<D;k++)
				ybar+=U[u][k]*V[v][k];
			ybar += (alpha[u]+beta[v]);
			double var = 0;
			
			for(int k=0;k<D;k++)
				var+=P[u][k]*Q[v][k];
			totalVar+=var;
			double temp_mse;
			if(!sigmoid)
				temp_mse = sqr(ybar-r);
			else
				temp_mse = sqr((g(ybar)-r)*4);
			MSE+=temp_mse;

			if(hisfp){
				mse_bar_test[i] = temp_mse;
				var_bar_test[i] = var;
			}
		}
		printf("testing error = %lf\n", sqrt(MSE/testCount));
		printf("average testing var = %lf\n",totalVar/testCount);
		if(hisfp)
			fprintf(hisfp,"%lf %lf %lf\n",sqrt(MSE/testCount),totalVar/testCount,rankcor(var_bar_test,mse_bar_test,buff_var_test,buff_mse_test,testData.size()));
		//printf("cor = %lf\n\n",rankcor(var_bar,mse_bar));
		puts("");
		//printf("\n norm of U, V, W: %lf, %lf, %lf\n",norm(U),norm(V),norm(W));
		//printf(" norm of alpha, beta, gamma: %lf, %lf, %lf\n",normVec(alpha,D),normVec(beta,M),normVec(gama,M));
	}
	time(&end);
	double seconds = difftime(end,start);
	printf("\ntraining takes %.f seconds\n\n",seconds);
	if(timefp)
		fprintf(timefp,"%lf\n",seconds);
	
	//if(logFile){
	double MSE = 0;
	double totalVar = 0;
	//double var_bar_train[trainData.size()];
	//double mse_bar_train[trainData.size()];
#pragma omp parallel for reduction(+:totalVar,MSE)
	for (int i = 0; i < trainData.size(); ++i){
		double ybar = 0;
		int u = trainData[i].u;
		int v = trainData[i].v;
		double r = trainData[i].r;
		for(int k=0;k<D;k++)
			ybar+=U[u][k]*V[v][k];
		ybar += (alpha[u]+beta[v]);

		double var = 0;
		for(int k=0;k<D;k++)
			var+=P[u][k]*Q[v][k];
		totalVar+=var;
		double temp_mse;
		if(!sigmoid)
			temp_mse = sqr(ybar-r);
		else
			temp_mse = sqr((g(ybar)-r)*4);
		MSE+=temp_mse;
		mse_bar_train[i] = temp_mse;
		var_bar_train[i] = var;
	}
	printf("final training error = %lf, variance = %lf\n",sqrt(MSE/trainCount),totalVar/trainCount);
	if(logfp){
		//FILE* logfp = fopen(logFile,"a");
		fprintf(logfp,"%lf %lf %lf ",sqrt(MSE/trainCount),totalVar/trainCount,rankcor(var_bar_train,mse_bar_train,buff_var_train,buff_mse_train,trainData.size()));
	}
	MSE = 0;
	totalVar = 0;
	//double var_bar[testData.size()];
	//double mse_bar[testData.size()];
#pragma omp parallel for reduction(+:totalVar,MSE)
	for (int i = 0; i < testData.size(); ++i){
		double ybar = 0;
		int u = testData[i].u;
		int v = testData[i].v;
		double r = testData[i].r;
		if(userSet.find(u)==userSet.end()||itemSet.find(v)==itemSet.end()){
			MSE+=sqr(r+trainMean-3);
			mse_bar_test[i] = sqr(r+trainMean-3);
			var_bar_test[i] = 0;
			continue;
		}

		for(int k=0;k<D;k++)
			ybar+=U[u][k]*V[v][k];
		ybar += (alpha[u]+beta[v]);
		double var = 0;
		
		for(int k=0;k<D;k++)
			var+=P[u][k]*Q[v][k];
		totalVar+=var;
		double temp_mse;
		if(!sigmoid)
			temp_mse = sqr(ybar-r);
		else
			temp_mse = sqr((g(ybar)-r)*4);
		MSE+=temp_mse;
		mse_bar_test[i] = temp_mse;
		var_bar_test[i] = var;
	}
	if(logfp){
		//FILE* logfp = fopen(logFile,"a");
		fprintf(logfp,"%lf %lf %lf %lf\n",sqrt(MSE/testCount),totalVar/testCount,rankcor(var_bar_test,mse_bar_test,buff_var_test,buff_mse_test,testData.size()),sparsity());
	}
	printf("final testing error = %lf, variance = %lf\n",sqrt(MSE/testCount),totalVar/testCount);
	if(predfp)
		predToFile(predfp);
	if(config)
		dumpModel(config);
	//}
	pthread_exit(NULL);
	return 0;
}

//g++ vmf.cpp -fopenmp -O3 -std=gnu++11 -o vmf -lpthread
//./vmf -train train.0.dat valid.0.dat -1 -test test.0.dat -ite 200 -D 20 -sigma_u 0.05 -sigma_v 0.05 -sigma 0.01 -lbda_p 0.1 -lbda_q 0.1 -lr_method 2 -lr 0.1
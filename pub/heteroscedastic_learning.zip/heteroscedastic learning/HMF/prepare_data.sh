cd MovieLens1M
echo "prepariing data for MovieLens1M"
python ml_data.py
cd ../MovieLens10M
echo "prepariing data for MovieLens10M"
python ml_data.py
cd ../Netflix
echo "prepariing data for Netflix"
python netflix_data.py
cd ..

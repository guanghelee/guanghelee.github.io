Heteroscedastic Matrix Factorization (HMF)
Training matrix factorization by heteroscedastic learning.
Please contact guanghe.lee0304@gmail.com if you have any question.


This implementation should be used in a linux environment.
The codes are written by C++, python and shell commands.
Dependency: g++, python2.7, OpenMP, gnu++11, POSIX Thread(pThread)

For those who want to reproduce experiment results in the paper:

Experiments in the paper are conducted in MovieLens1M, MovieLens10M (http://grouplens.org/datasets/movielens/), and Netflix (netflixprize.com) dataset.

1. Compile the code:

	sh compile.sh

2. Download MovieLens1M, MovieLens10M, and Netflix dataset, and put "ratings.dat" of MovieLens1M into the folder "MovieLens1M", put "ratings.dat" of MovieLens10M into the folder "MovieLens10M", and put the folder "training_set" of Netflix into the folder "Netflix".

3. Data preparation:

	sh prepare_data.sh

It will prepare 5 splits for each dataset as train.[0,4].dat, valid.[0,4].dat, test.[0,4].dat
If you want to produce experimental data for only specific dataset, you can "cd" to the folder of the dataset and run "python ml_data.py" or "python netflix_data.py".


4. Run the experiment in a specific dataset. For example, you can "cd" to "MovieLens1M" and

	sh run_hmf.sh

It will run HMF for each split of dataset once. If you want to run it more times, you can modify the script "run_dmf.sh".

5. Results of performance and running time is available in "MovieLens/log/". You can use the "collect.py" in the main folder to collect the results. For example, 

	python collect.py MovieLens1M/log/dmf.0
	python collect.py MovieLens1M/log/dmf.time.0

For those who want to further get the learning curve and prediction on testing data:

6. Run the experiment to generate learning curve and prediction file in MovieLens1M:

	cd MovieLens1M
	sh run_complete_HMF.sh

7. The learning curve will be "log/hmf.0.lr_curve". The prediciton file will be "prediction/hmf.0.predict". For data format of learning curve and prediction, please refers to below.





For those who want to use it for general purpose:

For general usage, data format of training and testing data should be prepared as follows (seperated by space),

	user_id1 item_id1 rating1
	user_id2 item_id2 rating2
	... ... ...

Data format of generated prediction file: The same as training and testing files

Data format of generated learning curve: (epoch1 is abbreviated as e1)

	train_RMSE_e1 train_average_variance_e1 train_rank_correlation_e1 test_RMSE_e1 test_average_variance_e1 test_rank_correlation_e1
	train_RMSE_e2 train_average_variance_e2 train_rank_correlation_e2 test_RMSE_e2 test_average_variance_e2 test_rank_correlation_e2
	... ... ... ... ... ...



1. Compile the code:

	sh compile.sh

2. Prepare your dataset.

3. Run "./HMF [Parameter flag] [Parameter value]". Example can be refers to "MovieLens1M/run_dmf.sh" and "MovieLens1M/run_complete_dmf.sh"

Legitimate [parameter flags] [parameter value] with explanation:

	[-train] ["data1"(string) "data2"(string) ... "dataN"(string) -1]	/ list of training data filename ended with -1.
	[-test] ["test_data"(string)]	/ testing data filename
	[-ite] [integer] 	/ number of epochs to run(double)(default=0)
	[-D] [integer]		/ dimension of latent factors(int)(default=0)
	[-sigma_U] [double] 	/	1/sigma^2_U(default=0.01)
	[-sigma_V] [double]		/	1/sigma^2_V(default=0.01)
	[-lbda_P] [double]	/	lbda_P(default=0.01)
	[-lbda_Q] [double]	/	lbda_Q(default=0.01)
	[-sigma] [double]	/	Delta sigma(default=0.01)
	[-lr_method] [integer]	/	Optimizer. 0 for Gradient Descent, 2 for AdaGrad
	[-lr] [double]		/	learning rate(default=0.01)

Optional parameters:

	[-v] []		/	verbose performance through iterations (it will prolong the training time.)
	[-log] ["log_name"(string)] 	/ appending log of performance after training on the "log_name"
	[-time_log] ["log_name"(string)] 	/ appending log of training time (not including I/O time) on the "log_name"
	[-lr_curve] ["log_name"(string)] 	/ write the learning curve into "log_name". [-v] is required.
	[-pred] ["predict_filename"(string)]	/ write the prediction of test data into "predict_filename". Format is the same with our data format.

Utilities:

1. collect results for log or time_log:

	python collect.py "log_file"

2. calculate RMSE between test_data and predict_data:

	python calRMSE.py "test_data" "predict_data"


#!/bin/sh
#for c in $(seq 1 100)
#do
for version in 0 1 2 3 4
do
        ../hmf -train train.$version.dat valid.$version.dat -1 -test test.$version.dat -ite 28 -D 500 -sigma_U 0.2 -sigma_V 0.04 -sigma 0.01 -lbda_P 0.75 -lbda_Q 0.75 -lr_method 2 -lr 0.025 -w -log log/hmf.$version -time_log log/hmf.time.$version
done
#done
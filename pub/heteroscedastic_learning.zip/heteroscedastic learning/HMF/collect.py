import sys, numpy

fileName = sys.argv[1]
counter = 1
with open(fileName) as fp:
	arr2d = []
	line = fp.readline()
	line = map(float,line.strip().split(' '))
	for i,ele in enumerate(line):
		arr2d.append([])
		arr2d[i].append(ele)
	for line in fp:
		counter+=1
		line = map(float,line.strip().split(' '))
		for i,ele in enumerate(line):
		#	arr2d.append([])
			arr2d[i].append(ele)
print counter,'lines'
if len(arr2d) == 7:
	prefix = ['train RMSE','train avg var','train rank cor','test RMSE','test avg var','test rank cor','1-sparsity']
elif len(arr2d)==5:
	prefix = ['train RMSE','train avg var','test RMSE','test avg var','1-sparsity']
elif len(arr2d)==1:
	prefix = ['running time (second)']
else:
	prefix = ['testing MSE']
for i in xrange(len(arr2d)):
	print '('+'%.4f' % numpy.mean(arr2d[i]) +','+ '%.4f' % numpy.std(arr2d[i])+')',prefix[i]
